<!doctype html> 
<html> 
<head> 
<meta charset="gb2312" /> 
<script type="text/javascript" src="tuna_090501.js" charset="utf-8"></script>

</head>
<body>
<div style="background-color:#999;padding:10px;">
		<h2>notice & address</h2>
		<button style="margin-bottom:30px;" onclick="change()">add one</button><br />
		<button style="margin-bottom:30px;" onclick="clean()">clean</button><br />
		<input type="text" value="" id="mod_test1"
			mod="notice|address"
			mod_notice_tip="hello world"
			mod_address_suggest="@China|�й���½|CN@China HongKong|�й����|HK@China Macau|�й�����|MO@China Taiwan|�й�̨��|TW@United States|����|US@United Kingdom|Ӣ��|GB@Japan|�ձ�|JP@Canada|���ô�|CA@France|����|FR@Korea,Republic of|����|KR@Germany|�¹�|DE@"
			mod_address_source="nationality"
			mod_address_reference="mod_hidden1" /><br />
		
		<input type="text" value="" id="mod_hidden1" autocomplete="off" />
	</div>
	<script>
		$r("beforeunload", function(){
			$pageValue.set("yan",$("mod_test1").value);
		});
		$r("domready", function(){
			var a = $pageValue.get("yan");
			$("mod_test1").value = a;
		});
		
	</script>
	
	<br />
	
<!-- ֻ��˵������ˢ�¾ͼǲ�ס�� -->
<?php
for($i = 0; $i < 100; $i++){
?>
	<div style="background-color:#999;padding:10px;">
		<h2>notice & address</h2>
		<button style="margin-bottom:30px;">add one</button><br />
		<input type="text" value="" id=""
			mod="notice|address"
			mod_notice_tip="hello world"
			mod_address_suggest="@China|�й���½|CN@China HongKong|�й����|HK@China Macau|�й�����|MO@China Taiwan|�й�̨��|TW@United States|����|US@United Kingdom|Ӣ��|GB@Japan|�ձ�|JP@Canada|���ô�|CA@France|����|FR@Korea,Republic of|����|KR@Germany|�¹�|DE@"
			mod_address_source="nationality"
			mod_address_reference="mod_hidden1" /><br />
	</div>
<?php }
?>

</body>
</html>
<script type="text/javascript">
function change(){
	$("mod_test1").value="����";
	$("mod_test1").module.address.check();
}

function clean(){
	$("mod_test1").value="";
	$("mod_test1").module.notice.check();
	//$("mod_test1").module.address.check();  //�������reference
}
</script>
