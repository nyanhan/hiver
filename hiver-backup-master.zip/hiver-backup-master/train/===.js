
"" == 0
"" === 0

1 === "1"
1 == "1"

? 1.0 ===1







null == 0 
null == !0
null == ""
null == null







[] == []
[] == ![]
[] == false
[] == 0







if( null )	alert(0);
if( 0 )	alert(0);
if( !null )	alert(0);
if( {} )	alert(0);
if( [] )	alert(0);
if( "" )	alert(0);







NaN  undefined











