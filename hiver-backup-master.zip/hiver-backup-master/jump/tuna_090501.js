﻿var $Ctrip="Copyright(C) Ctrip.COM 2008.All Rights Reserved.\n"+
	"Not to be reused without permission.\n"+
	"Created by Chu Chengdong, Tian Guofa UI group, IT department.\n"+
	"Last modified by Chu Chengdong, Tian Guofa, Cao Yue, Li Fan UI group, IT department. 2010\/09\/01";

//常用变量简写
var _=window;
var __=_.document;
var ___=__.documentElement;

//模块命名空间
var Ctrip={module:{}};

//全局变量
var $$={};

//浏览器判断
with (navigator){with(userAgent){
	$$.browser={
		IE:!!match(/MSIE/),
		IE6:!!appVersion.match(/MSIE 6\.0/i),	//是否为ie6
		Moz:match(/Mozilla/i)&&!match(/compatible|WebKit/i),
		Opera:!!match(/Opera/i),
		Safari:!!match(/Safari/i)
	};
}}

//检测顶层窗口
var $topWin=window;
(function(){
	try{
		while (true){
			var tmpWin=$topWin.parent;
			if (tmpWin&&tmpWin!=$topWin&&tmpWin.$Ctrip)
				$topWin=tmpWin;
			else
				return;
		}
		
	}catch(e){ };
})();

window.onerror = function(mes,url,line){
	$trackEvent('normal-error','normal',$error(mes,url,line), $tunaVersion());
	return false;
};

//数组扩展
$extend(Array.prototype, new function(){
	this.each = function(func){
		for (var i = 0, l = this.length; i < l; i++)
			if ((func?func(this[i],i):this[i]())===false) return false;
		return true;
	};
	this.random = function(){
		if(!this.length) return null;
		return this[Math.floor(Math.random() * this.length)];
	};
	this.randomize = function(){
		for(var i = 0, n = this.length; i < n; ++i){
			var j = Math.floor(Math.random() * n);
			var t = this[i];
			this[i] = this[j];
			this[j] = t;
		}
		return this;
	};
	if ($$.browser.IE)
		this.map = function(func){
			var arr=[];
			for (var i = 0, l = this.length; i < l; i++)
				arr.push(func(this[i]));
			return arr;
		};
});

//数值扩展
$extend(Number.prototype,new function(){
	this.parseCur=function(decimalDigits){
		var num=this.toFixed(decimalDigits||2),re=/(\d)(\d{3}[,\.])/;
		while(re.test(num))
			num=num.replace(re,"$1,$2");
		num=num.replace(/^(-?)\./,"$10.");
		return decimalDigits===0?num.replace(/\..*$/,""):num;
	};
});

//字符串扩展
$extend(String.prototype,new function(){
	this.replaceWith=function(obj){
		return this.replace(/\{\$(\w+)\}/g,function(s,k){
			if(k in obj)
				return obj[k];
			else
				return s;
		});
	};
	this.trim=function(){
		return this.replace(/^\s+|\s+$/g,'');
	};
	this.isEmail=function(){
		var re=/^[^@\s]+@[^@\.\s]+(\.[^@\.\s]+)+$/;
		return re.test(this);
	};
	this.isDateTime=function(defVal){
		var date=defVal===false?this:this.parseStdDate(false);
		if (!date) return false;
		var arr=date.match(/^((19|20)\d{2})-(\d{1,2})-(\d{1,2})$/);
		if (!arr) return false;
		for (var i=1;i<5;i++)
			arr[i]=parseInt(arr[i],10);
		if(arr[3]<1||arr[3]>12||arr[4]<1||arr[4]>31) return false;
		var _t_date=new Date(arr[1],arr[3]-1,arr[4]);
		return _t_date.getDate()==arr[4]?_t_date:null;
	};
	this.toReString=function(){
		return this.replace(/([\.\\\/\+\*\?\[\]\{\}\(\)\^\$\|])/g,"\\$1");
	};
	//判断身份证号码是否有效
	this.isChinaIDCard=function(){
		var num=this.toLowerCase().match(/./g);
		if (this.match(/^\d{17}[\dx]$/i)){
			var sum=0,times=[7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2];
			for (var i=0;i<17;i++)
				sum+=parseInt(num[i],10)*times[i];
			if ("10x98765432".charAt(sum%11)!=num[17])
				return false;
			return !!this.replace(/^\d{6}(\d{4})(\d{2})(\d{2}).+$/,"$1-$2-$3").isDateTime();
		}
		if (this.match(/^\d{15}$/))
			return !!this.replace(/^\d{6}(\d{2})(\d{2})(\d{2}).+$/,"19$1-$2-$3").isDateTime();
		return false;
	};
	this.parseStdDate=function(defVal){
		var month="January|1@February|2@March|3@April|4@May|5@June|6@July|7@August|8@September|9@October|10@November|11@December|12";
		var re=this.replace(/[ \-,\.\/]+/g,"-").replace(/(^|-)0+(?=\d+)/g,"$1");
		if ($$.status.version=="en")
			re=re.replace(/[a-z]{3,}/i,function(re){
				return (_t_re=month.match(new RegExp("(^|@)"+re+"[^\\|]*\\|(\\d+)","i")))?_t_re[2]:re;
			});
		re=re.replace(/^([^-]{1,2}-[^-]{1,2})-([^-]{4})$/,"$2-$1");
		return defVal===false||re.isDateTime(false)?re:null;
	};
	this.parseEngDate=function(){
		var std=this.parseStdDate();
		if (!std) return null;
		var re=std.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
		return "Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec".split("|")[parseInt(re[2])-1] +"-"+re[3]+"-"+re[1];
	};
});

//日期扩展
$extend(Date.prototype,new function(){
	this.dateValue=function(){
		return new Date(this.getFullYear(),this.getMonth(),this.getDate());
	};
	this.addDate=function(day){
		return new Date(this.getFullYear(),this.getMonth(),this.getDate()+day);
	};
	this.toStdString=function(){
		return this.getFullYear()+"-"+(this.getMonth()+1)+"-"+this.getDate();
	};
	this.toEngString=function(){
		return "Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec".split("|")[this.getMonth()] +"-"+this.getDate()+"-"+this.getFullYear();
	};
});

//函数扩展
$extend(Function.prototype,new function(){
	this.bind = function(obj){
		var fn = this;
		var ar = [].slice.call(arguments, 1);
		return function(){
			return fn.apply(obj, ar.concat([].slice.call(arguments, 0)));
		};
	};
	this.pass = function(){
		var ar = [].slice.call(arguments, 0);
		ar.unshift(null);
		return this.bind.apply(this, ar);
	};
	this.delay = function(n){
		return setTimeout(this, n);
	};
});

//页面cookie
$$.cookie={
	domain:null,
	path:null,
	expires:null
};

//页面history临时函数
$$.history={
	load:function(){
		setTimeout($$.history.load,200);
	}
};

//输出js控件容器
_.__.write("<div id=\"jsContainer\"><div id=\"jsHistoryDiv\" style=\"display:none;\">"+($$.browser.IE?"":"<iframe id=\"jsHistoryFrame\" name=\"jsHistoryFrame\" onload=\"$$.history.load();\" src=\"about:blank\"><\/iframe>")+"<\/div><textarea id=\"jsSaveStatus\" style=\"display:none;\"><\/textarea><div id=\"tuna_jmpinfo\" style=\"visibility:hidden;position:absolute;z-index:120;overflow:hidden;\"><\/div><div id=\"tuna_alert\" style=\"display:none;position:absolute;z-Index:999;overflow:hidden;\"><\/div><\/div>");

//全局状态
$$.status=new function(){
	this.domReady=false;	//页面是否已加载
	this.load=false;
	this.busy=0;
	this.dealt={};
	this.regEventCount=0;
	this.regEventHash={};
	this.charset=(((_.__.charset?_.__.charset:_.__.characterSet)||"")
		.match(/^(gb2312|big5|utf-8)$/gi)||"gb2312").toString().toLowerCase();
	this.version={
		"gb2312":"zh-cn",
		"big5":"zh-tw",
		"utf-8":"en"
	}[this.charset];
	//this.chs=!this.charset.toString().match(/^utf-8$/g);
	var script=$topWin.__.getElementsByTagName("script");
	this.debug=false;
	this.debugEvent=false;
	this.alertDiv=_.__.getElementById("tuna_alert");
	this.container=_.__.getElementById("jsContainer");
	this.saveStatus=_.__.getElementById("jsSaveStatus");
	this.back=false;
	this.pageValue={data:{}};
	this.globalValue={};
	this.today=new Date().toStdString();
};

//页面history
$$.history={
	isFirefox2:/Firefox\/2\.0\.0\.\d+/.test(navigator.userAgent),
	enabled:false,
	callback:{},
	info:{"#":["#","","",""]},
	current:"#",
	blank:"blank.html",
	div:_.__.getElementById("jsHistoryDiv"),
	frame:_.frames["jsHistoryFrame"],
	iframe:null,
	isReady:false,
	count:0,
	init:function(){
		if (_.$$.history.frame)
			return;
		this.div.innerHTML="<iframe id=\"jsHistoryFrame\" name=\"jsHistoryFrame\" src=\""+this.blank+"\" onload=\"$$.history.load();\"><\/iframe>";
		this.frame=_.frames["jsHistoryFrame"];
		this.iframe=$("jsHistoryFrame");
	},
	load:function(){
		this.isReady=true;
		$r("domReady",function(){
			var k=0;
			setInterval(function(){
				var hashName=(_.$$.history.isFirefox2?_:_.$$.history.frame).location.hash.replace(/^#/,"")||"#";
				if (hashName!=_.$$.history.current){
					if (k<1)
						k++;
					else{
						_.$$.history.current=hashName;
						var info=_.$$.history.info[hashName];
						if (info){
							$t("[history]返回标志:"+info[0]+"/"+hashName,"green",info.join("\t"));
							var callback=_.$$.history.callback[info[0]];
							if (typeof callback=="function")
								callback.apply(info[0],info.slice(1));
						}
						if ($$.browser.Opera)
							_.$saveHistory();
					}
				}else
					k=0;
			},100);
		});
		$t("[history]初始化完成","green");
		var hashName=(_.$$.history.isFirefox2?_:_.$$.history.frame).location.hash.replace(/^#/,"")||"#";
		$t("[history]返回标志:"+hashName,"green");
		this.load=function(){};
	}
};

//模块变量
$$.module={
	iframe:[],
	list:{},
	tab:{},
	selectAll:{},
	address:{
		source:{}
	},
	calendar:{},
	init:[]
};

//模块字符串
$$.string={
	"zh-cn":{
		weekday:"日一二三四五六",
		display:"@▲|▼@显示|隐藏@"
	},
	"zh-tw":{
		weekday:"日一二三四五六",
		display:"@▲|▼@顯示|隱藏@"
	},
	"en":{
		weekday:"SMTWTFS",
		display:"@Show|Hidden@"
	}
}[$$.status.version];

//访问器变量
$$.access={};

//扩展
function $extend(a){
	for(var i = 1; i < arguments.length; i ++){
		var b = arguments[i];
		for(var s in b) if(b.hasOwnProperty(s)) a[s] = b[s];
	}
	return a;
}

//合并
function $merge(){
	return $extend.apply(null, [{}].concat([].slice.call(arguments, 0)));
}

//检测变量类型
function $type(obj){
	var typ = typeof obj;
	if(typ != 'object' && typ != 'function') return typ;
	if(obj == null) return 'null';
	var h = {
		'array': Array,
		'boolean': Boolean,
		'date': Date,
		'regexp': RegExp,
		'string': String,
		'number': Number,
		'function': Function
	};
	for(var s in h) if((obj instanceof h[s]) || obj.constructor == h[s]) return s;
	return typ;
}

//获取hash键数组
function $keys(obj, full){
	var ret = [];
	for(var s in obj) if(full || obj.hasOwnProperty(s)) ret.push(s);
	return ret;
}

//获取hash值数组
function $values(obj, full){
	var ret = [];
	for(var s in obj) if(full || obj.hasOwnProperty(s)) ret.push(obj[s]);
	return ret;
}

//获取hash键值对数组
function $items(obj, full){
	var ret = [];
	for(var s in obj) if(full || obj.hasOwnProperty(s)) ret.push([s, obj[s]]);
	return ret;
}

//类
function $class(props, f0){
	var me = arguments.callee;
	var f1 = function(){};
	if(f0){
		f1.prototype = new f0();
		f1.prototype.constructor = f0;
	}
	var f2 = function(){
		var caller = arguments.callee.caller;
		if(caller == me || caller == f2.create) return;
		if(this.initialize) this.initialize.apply(this, arguments);
	};
	f2.prototype = new f1();
	$extend(f2.prototype, props || {}, {
		constructor: f2,
		proto: f2.prototype,
		base: f1.prototype
	});
	$extend(f2, {
		create: function(a){
			var o = new f2();
			if(o.initialize) o.initialize.apply(o, a);
			return o;
		},
		subclass: function(props){
			return me(props, f2);
		},
		implement: function(x, y){
			if($type(x) == 'string'){
				f2.prototype[x] = y;
			}else{
				[].slice.call(arguments).each(function(o){
					if($type(o) == 'function') o = new o();
					$items(o, true).each(function(a){f2.prototype[a[0]] = a[1]});
				});
			}
		}
	});
	return f2;
}

//获取页面尺寸
function $pageSize(maskType){
	var ret = {
		docWidth: ___.scrollWidth,
		docHeight: ___.scrollHeight,
		
		winWidth: ___.clientWidth,
		winHeight: ___.clientHeight,
		
		scrollLeft: $$.browser.Safari ? __.body.scrollLeft : ___.scrollLeft,
		scrollTop: $$.browser.Safari ? __.body.scrollTop : ___.scrollTop
	};
	if($$.browser.Safari){
		var st = ___.$getStyle();
		ret.docWidth += parseInt(st.marginLeft) + parseInt(st.marginRight);
		ret.docHeight += parseInt(st.marginTop) + parseInt(st.marginBottom);
	}
	
	ret.docWidth = Math.max(ret.docWidth,ret.winWidth);
	ret.docHeight = Math.max(ret.docHeight,ret.winHeight);
	
	if(maskType){
		var sm = maskType == 'win';
		ret.left = sm ? ret.scrollLeft : 0;
		ret.top = sm ? ret.scrollTop : 0;
		if($$.browser.Moz){
			var st = ___.$getStyle();
			ret.left -= parseInt(st.borderLeftWidth) + parseInt(st.marginLeft);
			ret.top -= parseInt(st.borderTopWidth) + parseInt(st.marginTop);
		}
		ret.width = sm ? ret.winWidth : Math.max(ret.docWidth, ret.winWidth);
		ret.height = sm ? ret.winHeight : Math.max(ret.docHeight, ret.winHeight);
	}
	
	return ret;
}

//页面动画
function $animate(target, props, config){
	if(!target || !target.style) return;
	target = target.style;
	
	var config = $extend({
		fps: 40,
		duration: 400,
		callback: function(){},
		reverse: false,
		fn: function(x){return Math.sin(x * Math.PI / 2)}
	}, config || {});
	
	var flds = $keys(props);
	var units = flds.map(function(f){
		return /(width|height|left|top)\b/i.test(f) ? 'px' : '';
	});
	var start = new Date();
	var ani = function(){
		var d = new Date() - start;
		if(d > config.duration) d = config.duration;
		for(var j = 0; j < flds.length; j ++){
			var f = props[flds[j]];
			var x = config.fn(d / config.duration);
			var n = config.reverse ? f[1] + (f[0] - f[1]) * x : f[0] + (f[1] - f[0]) * x;
			if(units[j] == 'px') n = Math.round(n);
			target[flds[j]] = n + units[j];
		}
		if(d == config.duration){
			clearInterval(timer);
			if(config.callback) setTimeout(config.callback, Math.round(1000 / config.fps));
		}
	};
	var timer = setInterval(ani, Math.round(1000 / config.fps));
	
	ani();
	return timer;
}

//多元素动画
/*
$animate2([
[elA.style, {
	width: [10, 200, 'px'],
	height: [20, 200, 'px']
}],[elB, {
	scrollLeft: [0, 10, 0],
	scrollTop: [50, 10, 0]
}]
], {duration: 1000})
*/
function $animate2(x, j) {
	var j = $merge({
		fps:40,
		duration:400,
		callback:function () {},
		reverse:false,
		fn:function (a) {return Math.sin(a * Math.PI / 2);}
	}, j || {});
	var m = new Date;
	var s = function () {
		var a = new Date - m;
		if (a > j.duration) a = j.duration;
		var y = j.fn(a / j.duration);
		for (var c = 0; c < x.length; c++) {
			var o = x[c][0];
			var b = x[c][1];
			for(var f in b){
				var d = b[f];
				var g = j.reverse ? d[1] + (d[0] - d[1]) * y : d[0] + (d[1] - d[0]) * y;
				if(d[2] == 'px' || d[3]) g = Math.round(g);
				o[f] = g + d[2];
			}
		}
		if (a == j.duration) {
			clearInterval(q);
			if (j.callback) setTimeout(j.callback, Math.round(1000 / j.fps));
		}
		return arguments.callee;
	};
	var q = setInterval(s(), Math.round(1000 / j.fps));
	return q;
}

//修正事件对象
function $fixE(e){
	e=_.event||e||arguments.callee.caller.arguments[0];
	$(e.$target=e.target?(e.target.nodeType&&e.target.nodeType==3?e.target.parentNode:e.target):e.srcElement);
	return e;
}

//阻止默认事件，阻止冒泡
function $stopEvent(e,flag){
	e=$fixE(e);
	flag=flag||0;
	if (flag>=0) e.preventDefault?e.stopPropagation():(e.cancelBubble=true);
	if (flag!=0) e.preventDefault?e.preventDefault():(e.returnValue=false);
}

//获得随机id
function $getUid(){
	return "uid_"+(new Date()).getTime()+Math.random().toString().substr(2,5);
}

//创建dom节点
function $c(tag){
	if (tag.constructor==Array) return $(__.createTextNode(tag.join("\n")));
	else return $(__.createElement(tag));
}
var $createElement=$c;

//变量转换为json字符串
function $toJson(variable){
	if(variable === null) return 'null';
	if (typeof variable=='undefined') return 'undefined';
	switch (variable.constructor){
		case Object:
			var arr=[],value;
			for (var name in variable)
				arr.push($toJson(name)+":"+$toJson(variable[name]));
			return "{"+arr.join(",")+"}";
		case Array:
			return "["+variable.map(function(em){
				return $toJson(em);
			}).join(",")+"]";
		case String:
			return "\""+variable.replace(/([\n\r\\\/\'\"])/g,function(a){
				return {"\n":"\\n","\r":"\\r"}[a]||"\\"+a;
			})+"\"";
		case Date:
			return "new Date("+variable.getTime()+")";
		case Number:
		case Boolean:
		case Function:
		case RegExp:
			return variable.toString();
		default:
			return "null";
	}
}

//json字符串转换为变量
function $fromJson(str){
	var undefined;
	var variable=null;
	try {
		variable=eval("("+str+")");
	} catch(e){
		$trackEvent('tuna-error', '$fromJson', $error(e), $tunaVersion());
	};
	return variable;
}

//页面变量
function $pageValue(){
	return $pageValue.get.apply(_,arguments);
}

//保存页面变量
$pageValue.set=function(name,value,historyHash){
	historyHash=historyHash||$$.history.current;
	if (!(historyHash in $$.status.pageValue.data))
		$$.status.pageValue.data[historyHash]={};
	$$.status.pageValue.data[historyHash][name]=value;
	if ($$.browser.Opera)
		$savePageValue();
};

//获取页面变量
$pageValue.get=function(name,historyHash){
	var hash=$$.status.pageValue.data[historyHash||$$.history.current];
	return hash&&name in hash?hash[name]:null;
};

//删除页面变量
$pageValue.del=function(name,historyHash){
	var hash=$$.status.pageValue.data[historyHash||$$.history.current];
	if (hash){
		delete hash[name];
		if ($$.browser.Opera)
			$savePageValue();
	}
};

//保存pageValue
function $savePageValue(){
	$$.status.saveStatus.value=$toJson($$.status.pageValue);
}

//保存History
function $saveHistory(){
	var arr1=[];
	for (var hashName in $$.history.info){
		var info=$$.history.info[hashName];
		if (info.constructor==Array&&info.length==4){
			var arr2=[hashName];
			for (var i=0;i<info.length;i++)
				arr2.push(escape(info[i]||""));
			arr1.push(escape(arr2.join("|")));
		}
	}
	$$.status.pageValue["historyInfo"]=arr1.join("|");
	$$.status.pageValue["historyCount"]=$$.history.count;
	if ($$.history.frame)
		$$.status.pageValue["lastHistory"]=$$.history.frame.location.href;
	$savePageValue();
}

//跨页面变量
function $globalValue(){
}

//获取get参数
function $getQuery(name){
	var query=(location.search||"").match(new RegExp("[\\?&]"+name+"=([^&]+)","i"));
	return query?unescape(query[1]):null;
}

//动态加载js
function $loadJs(url, charset, callback, timeout) {
	var me = arguments.callee;
	var queue = me.queue || (me.queue = {});
	var timer = null;
	if(!(url in queue)){
		queue[url] = [];
		if(callback){
			timer = setTimer();
			queue[url].push(callback);
		}
	}else{
		if(callback){
			if(queue[url]){
				timer = setTimer();
				queue[url].push(callback);
			}else{
				callback();
			}
		}
		return;
	}
	var script = document.createElement('script');
	script.type = 'text/javascript';
	script.charset = charset || $$.status.charset;
	script.onload = script.onreadystatechange = function(){
		if(script.readyState && script.readyState!= 'loaded' && script.readyState != 'complete') return;
		if(timer) clearTimeout(timer);
		script.onreadystatechange = script.onload = null;
		while(queue[url].length) queue[url].shift()();
		queue[url] = null;
	};
	script.src = url;
	__.getElementsByTagName('head')[0].appendChild(script);
	
	function setTimer(){
		var arr = queue[url];
		var pos = arr.length;
		if(callback && timeout){
			return setTimeout(function(){
				if(callback(true) !== true) arr.splice(pos, 1);
			}, timeout);
		}
	}
}

//动态加载css
function $loadCss(file,charset){
	if ($$.browser.IE)
		__.createStyleSheet(file).charset=charset||_.$$.status.charset;
	else{
		var css=_.__.createElement("link");
		with (css){
			type="text\/css";
			rel="stylesheet";
			href=file;
		}
		__.$("head")[0].appendChild(css);
	}
}

//获取cookie
function $getCookie(name,subkey){
	var arr=__.cookie.match(new RegExp("(?:^|;)\\s*"+encodeURIComponent(name)+"=([^;]+)"));
	if (subkey===false)
		return arr?arr[1]:null;
	if (arr&&subkey)
		arr=arr[1].match(new RegExp("(?:^|&)\\s*"+encodeURIComponent(subkey)+"=([^&]+)"));
	return arr?decodeURIComponent(arr[1]):null;
}

//删除cookie
function $delCookie(name,subKey){
	if (subKey){
		var orginalValue=$getCookie(name,false);
		if (orginalValue===null)
			return;
		orginalValue=orginalValue.replace(new RegExp("(^|&)\\s*"+encodeURIComponent(subKey)+"=[^&]+"),"").replace(/^\s*&/,"");
		if (orginalValue){
			__.cookie=encodeURIComponent(name)+"="+orginalValue;
			return;
		}
	}
	var expires=new Date();
	expires.setTime(expires.getTime()-1);
	__.cookie=encodeURIComponent(name)+"=;expires="+expires;
}

//设置cookie
function $setCookie(name,subKey,value){
	if (!value){
		value=subKey;
		subKey=null;
	}
	var extInfo=($$.cookie.domain?"; domain="+$$.cookie.domain:"")+"; path="+($$.cookie.path||"/")+($$.cookie.expires?"; expires="+new Date((new Date()).getTime()+$$.cookie.expires*3600000).toGMTString():"");
	if (subKey){
		var orginalValue=$getCookie(name,false)||"";
		if (orginalValue)
			orginalValue=(orginalValue+"&").replace(new RegExp("(^|&)\\s*"+encodeURIComponent(subKey)+"=[^&]+&"),"$1");
		__.cookie=encodeURIComponent(name)+"="+orginalValue+encodeURIComponent(subKey)+"="+encodeURIComponent(value)+extInfo;
	}else
		__.cookie=encodeURIComponent(name)+"="+encodeURIComponent(value)+extInfo;
}

//模块初始化
function $init(func){
	if (func) $topWin.$$.module.init.push(func);
	else $topWin.$$.module.init.each();
}

//正则加载模块
function $parserRe(obj){
	var objList=[];
	var re_mod=/<[^>]+\smod=[\'\"]?([\w|]+)[^>]+/g;
	var re_id=/\sid=[\'\"]?([^\s>\'\"]+)/i;
	var pa=null;
	var id=null;
	var el=null;
	(obj&&obj.innerHTML?obj:__.body).innerHTML.replace(re_mod,function(tag,mod){
		try{
			if(mod=="jmpInfo"){
				//todo: loadCss
			}else if((id=tag.match(re_id))&&(el=$(id[1]))){
				if(mod in Ctrip.module)
					new Ctrip.module[mod](el);
				else
					objList.push(el)
			}
		}catch(e){
			$t("parserRe函数错误:"+func.toString().slice(0,50)+"...","red");
			$trackEvent('tuna-error', '$parserRe',$error(e), $tunaVersion());
		};
		return "";
	});
	var clock=setInterval(function(){
		var obj=objList.shift();
		if (obj)
			$topWin.$d(obj);
		else
			clearInterval(clock);
	},50);
}

//加载模块
function $d(obj){
	($(obj).getAttribute("mod")||"").replace(/\w+/ig,function(mod){
		if (Ctrip.module[mod]){
			new Ctrip.module[mod](obj);
		}else{
			$t("错误:元素["+(obj.id||obj.tagName)+"]引用未知模块["+mod+"]","red");
			$trackEvent('tuna-error', '$d', [obj.id || obj.tagName, mod].join('; '), $tunaVersion());
		}
	});
}
var $dealElement=$d;

//变量访问器
function $i(name){
	var access=$$.access[name];
	if (access)
		return access;
	else{
		access=new function(){
			var getFuncList=[],setFuncList=[];
			this.get=function(){
				var value=access.value;
				for (var i=0;i<getFuncList.length;i++){
					var tmpValue=getFuncList[i].call(value);
					if (typeof tmpValue!='undefined')
						value=tmpValue;
				}
				return value;
			};
			this.set=function(value){
				for (var i=0;i<setFuncList.length;i++){
					var tmpValue=setFuncList[i].call(value);
					if (typeof tmpValue!='undefined')
						value=tmpValue;
				}
				return access.value=value;
			};
			this.regGet=function(func){
				if (!func)
					getFuncList=[];
				else
					getFuncList.push(func);
				return;
			};
			this.regSet=function(func){
				if (!func)
					setFuncList=[];
				else
					setFuncList.push(func);
				return;
			};
		};
	}
	return $$.access[name]=access;
}

//修复元素
function $fixElement(obj){
	function addEvent(el,evt,fn){
		if('attachEvent' in el)
			el.attachEvent('on'+evt,fn);
		else
			el.addEventListener(evt,fn);
	}
	function firstInput(el){
		el=el.getElementsByTagName('input');
		for(var i=0;i<el.length;i++)
			if(/checkbox|radio/.test(el[i].type))
				return el[i];
		return null;
	}
	function srcElement(e){
		if(!e)
			e=window.event;
		return e.srcElement||e.target;
	}
	function mover(lbl){
		var box=lbl._for;
		if(box){
			lbl.htmlFor=box.id||(box.id=$getUid());
			lbl._for=null;
		}
		var sty=lbl.style;
		sty.borderBottom='#aaa 1px dashed';
		sty.paddingBottom='0px';
		sty.color='#1E1A75';
	}
	function mout(lbl){
		var sty=lbl.style;
		sty.borderBottom='';
		sty.paddingBottom='';
		sty.color='';
	}
	obj=obj&&obj.nodeType?obj:_.__;
	if ($$.browser.IE6){
		var label=obj.getElementsByTagName("label");
		for (var i=0;i<label.length;i++){
			var el=firstInput(label[i]);
			if(el&&/checkbox|radio/.test(el.type))(function(lbl,box){
				lbl._for=box;
				addEvent(lbl,'mouseover',function(){mover(lbl)});
				addEvent(lbl,'mouseout',function(){mout(lbl)});
			})(label[i],el);
		}
	}
	if ($$.browser.IE){
		var select=obj.getElementsByTagName("select");
		for (var i=0;i<select.length;i++)
			select[i].onmousewheel=function(){
				return false;
			};
	}
}

//移除
function $removeTextNode(parent){
	if (!parent)
		return;
	var obj=parent.firstChild,objTmp;
	while (obj){
		objTmp=obj.nextSibling;
		if (obj.nodeType==3){
			if (!obj.nodeValue.trim())
				parent.removeChild(obj);
		}else
			$removeTextNode(obj);
		obj=objTmp;
	}
	return parent;
}

function $ajax(url,content,callback,historyName){
	var xmlVer=["MSXML2.XMLHTTP","Microsoft.XMLHTTP"],xmlObj;
	try {
		xmlObj=new XMLHttpRequest();
	} catch(e) {
		for (var i=0;i<xmlVer.length;i++)
			try {
				xmlObj=new ActiveXObject(xmlVer[i]);
				break;
			} catch(e) {}
	}
	if (!xmlObj){
		$trackEvent('tuna-error', '$ajax', 'xmlObj creation failure', $tunaVersion());
		return;
	}
	xmlObj.open(content?"POST":"GET",url||location.href,!!callback);
	xmlObj.setRequestHeader("Content-Type","application\/x-www-form-urlencoded");
	xmlObj.setRequestHeader("If-Modified-Since",new Date(0));
	function getReturnValue(){
		if ($$.history.enabled&&historyName){
			$$.history.init();
			var hashName="ajaxHistory_"+$$.history.count++;
			$$.history.current=hashName;
			(function(){
				if ($$.history.isReady){
					var info=$$.history.info[hashName]=[historyName,xmlObj.status==200?xmlObj.responseText:null,url,content];
					if ($$.history.isFirefox2)
						location.hash=hashName;
					else
						$$.history.frame.location.href=$$.history.blank+($$.browser.IE?"?"+!($$.history.count%2):"")+"#"+hashName;
					if ($$.browser.Opera)
						$saveHistory();
					$t("[history]增加历史:"+info[0]+"/"+hashName,"green",info.slice(1).join("\n"));
				}else
					setTimeout(arguments.callee,50);
			})();
		}
		return (xmlObj.status==200?(/xml/i.test(xmlObj.getResponseHeader("content-type"))?xmlObj.responseXML:xmlObj.responseText):null);
	}
	if (callback)
		xmlObj.onreadystatechange=function(){
			if (xmlObj.readyState==4){
				var txt=getReturnValue();
				if (callback(txt)===true){
					setTimeout(function(){
						$ajax(url,content,callback);
					},1000);
				}
			}
		};
	xmlObj.send(content||"");
	return callback?xmlObj:getReturnValue();
}

//显示debug窗口
function $showDebug(e){
	var key=e.keyCode||e.charCode;
	if ($$.status.debug&&key==192){
		var obj=$getDebug();
		if (obj&&(obj=obj.frameElement))
			obj.style.display=obj.style.display==""?"none":"";
	}
}

//获取debug窗口
function $getDebug(){
	var obj=$topWin.frames["Ctrip_debug"];
	if (obj) return obj;
	with(obj=$topWin.$c("iframe")){
		frameBorder=0;
		id=name="Ctrip_debug";
		with (style){
			border="1px solid red";
			width="600px";
			height="300px";
			position=$$.browser.IE6?"absolute":"fixed";
			bottom=right="10px";
			background="white";
		}
	}
	$topWin.$$.status.container.appendChild(obj);
	if ($$.browser.IE6)
		$topWin.$r("scroll",function(){
			with($("Ctrip_debug").style){
				zoom=1;
				zoom=0;
			}
		});
	with((obj=$getDebug()).document){
		open();
		write("<style>body{margin:0;padding:0;font-family:Arial;font-size:12px;overflow:scroll;}div{border-bottom:1px solid #CCC;}<\/style><body><\/body>");
		close();
	}
	$topWin.__.$r("keydown",$showDebug);
	return obj;
}

//输出调试信息
function $t(info,color,title){
	if (!$topWin.$$.status.debug)
		return;
	if (_!=$topWin)
		return $topWin.$t(info,color);
	var obj=$getDebug();
	var time=new Date().getTime()%(1E7);
	var msg="<font id=\"msg_"+time+"\"> "+info+"<\/font>";
	var div=obj.document.createElement("div");
	if (color)
		div.style.color=color||"black";
	if (title)
		div.title=title;
	div.innerHTML="<font style=\"color:blue;\">"+time+"<\/font> "+msg;
	with (obj.document.body){
		if (firstChild)
			insertBefore(div,firstChild);
		else
			appendChild(div);
	}
	return info;
}

//发送事件信息到uiServer2
function $trackEvent(category, action, label, value){
	if(window.console){
		window.console.log('$trackEvent: {$0}, {$1}, {$2}, {$3}'.replaceWith(arguments));
	}
	return;
}

//错误信息处理
function $error(e){
	if(!e)	return "";
	var name,message,line,file;
	if(e.message){
		if($$.browser.Opera){
			var transed = transErrMessage(e.message);
			name = "";
			message = this.transed[2];
			line = this.transed[1];
			file = this.transed[3].match(/.+((?:file:|http:)[^\s]+?)\s+.+/i)[1];
		}
		else{
			name = e.name || '';
			message = e.message || "";
			line = e.lineNumber || e.line || "";
			file = e.fileName || e.sourceURL || "";
		}
	}
	else if (!e.message&&(arguments[2]||arguments[2] == 0)){
		message = e;
		name = "";
		line = arguments[2];
		file = arguments[1];
	}
	return [name,message,line,file].join('|');
}
function transErrMessage(str){
	var  arr = [];
	arr = str.match(/Statement[^\d]+(\d+)\:([\s\S]+)Backtrace\:([\s\S]+)/);
	return arr;
}

//取tuna版本
function $tunaVersion(){
	var me = arguments.callee;
	if(!me._val){
		me._val = -1;
		for(var st = document.getElementsByTagName('script'), i = st.length - 1; i >= 0; i--){
			var m = st[i].src.match(/\/tuna_(\d+).js$/i);
			if(m){
				me._val = parseInt('20' + m[1]);
				me._offline = /\/webresint\.sh\.ctriptravel\.com\//i.test(st[i].src);
				me._english = /\/webresource\.english\.ctrip\.com\//i.test(st[i].src);
				break;
			}
		}
	}
	return me._val;
}
//是否为online环境
function $isOnline(){
	$tunaVersion();
	return !$tunaVersion._offline && !$tunaVersion._english;
}
//选择正确的webresource服务器, 构造url
function $webresourceUrl(url){
	$tunaVersion();
	var h = ['ource.ctrip', 'ource.english.ctrip', 'int.sh.ctriptravel'];
	var i = $tunaVersion._offline ? 2 : $tunaVersion._english ? 1 : 0;
	return 'http://webres' + h[i] + '.com' + url;
}
//选择正确的pic服务器, 构造url
function $picUrl(url){
	$tunaVersion();
	var h = ['.ctrip', '.english.ctrip', 'int.sh.ctriptravel'];
	var i = $tunaVersion._offline ? 2 : $tunaVersion._english ? 1 : 0;
	return 'http://pic' + h[i] + '.com' + url;
}


//DOM节点扩展
var DOM=function(){
	if (!this||this.nodeType==3||this.$) return this;
	this.module={};
	this.module.event={};
	//DOM公共函数
	function getFuncName(func){
		return (func.toString().match(/function([^\{]+)/i)||["","anonymous"])[1].replace(/\(\)/,"").trim()||"anonymous";
	}
	function getEventInfo(eventInfo){
		var str="["+eventInfo.event+"] ";
		str+=eventInfo.obj.tagName||{3:eventInfo.obj.nodeValue,9:"document"}[eventInfo.obj.nodeType||""]||"window";
		str+=eventInfo.obj.id?"#"+eventInfo.obj.id:(eventInfo.obj.name?"@"+eventInfo.obj.name:"");
		str+=" "+getFuncName(eventInfo.func);
		return str;
	}
	function execEvent(obj){
		return function(e){
			e=$fixE(e);
			var eventInfoList=obj.module.event[e.type],value;
			for (var i=0;i<eventInfoList.length;i++){
				if (eventInfoList[i].enabled){
					try{
						value=eventInfoList[i].func.call(obj,e);
						if ($topWin.$$.status.debugEvent)
							$t(getEventInfo(eventInfoList[i])+" ("+(typeof value=="undefined"?"无返回值":value.toString().slice(0,100))+")",null,eventInfoList[i].func);
						if (value===false)
							break;
					}catch(ex){
						$t(getEventInfo(eventInfoList[i])+" (执行错误)","red",eventInfoList[i].func);
						$trackEvent(
							'tuna-error', 'DOM.execEvent', $error(ex), $tunaVersion()
						);
					};
				}else{
					eventInfoList.splice(i,1);
					i--;
				}
			}
			return value;
		}
	}
	if (this.__)
		this.$=function(objId,flag){
			if (typeof objId=="object")
				return DOM.apply(objId);
			var obj;
			if (flag){
				var arr=___.innerHTML.match(new RegExp("\\sid=([\\\'\\\"]?)([\\w$]+?[_$]"+objId.toReString()+")\\1"),"g");
				if (arr){
					for (var i=0;i<arr.length;i++){
						obj=$(arr[i]);
						if (obj)
							return obj;
					}
				}
				return $(objId);
			}else
				obj=__.getElementById(objId);
			return obj?$(obj):null;
		};
	else
		this.$=function(objTag){
			var obj=this.getElementsByTagName(objTag);
			obj.$each=function(func){
				var flag;
				if (obj.length!==undefined)
					for (var i=0;i<obj.length&&(flag=func.call(this,obj[i],i))!==false;i++);
				else func.call(this,obj,0);
				return flag===false?0:1;
			};
			for (var i=0;i<obj.length;i++) $(obj[i]);
			return obj;
		};
	if (this.nodeType==1){
		if (this.tagName=="INPUT"&&/^(text|hidden)$/i.test(this.type)||this.tagName=="TEXTAREA")
			this.isNull=function(){
				return !this.value.trim();
			};
		if (/^SELECT$/.test(this.tagName))
			this.$setValue=function(value){
				for (var i=0;i<this.options.length;i++){
					if (this.options[i].value==value){
						this.selectedIndex=i;
						return true;
					}
				}
				return false;
			};
	}
	if (!this.hasAttribute)
		this.hasAttribute=function(str){
			return typeof this.attributes[str]!="undefined";
		};
	this.$parentNode=function(str){
		var obj=$(this.parentNode);
		if (str&&obj&&obj.tagName&&obj.tagName.toLowerCase()!=str.toLowerCase())
			obj=obj.$parentNode(str);
		return obj&&obj.tagName?obj:null;
	};
	this.$firstChild=function(){
		return $(this.firstChild);
	};
	this.$lastChild=function(){
		return $(this.lastChild);
	};
	this.$childNodes=function(){
		var obj=this.childNodes;
		for (var i=0;i<obj.length;i++)
			$(obj[i]);
		return obj;
	};
	this.$nSib=this.$nextSibling=function(){
		return $(this.nextSibling);
	};
	this.$pSib=this.$previousSibling=function(){
		return $(this.previousSibling);
	};
	this.$click=function(){
		if (this.click)
			this.click();
		else{
			var evt=__.createEvent("MouseEvents");
			evt.initMouseEvent("click",true,true,_,0,0,0,0,0,false,false,false,false,0,this);
			this.dispatchEvent(evt);
		}
	};
	this.$getStyle=function(style){
		var css=this.currentStyle||_.getComputedStyle(this,null);
		return style?css[style]:css;
	};
	this.$getPara=function(){
		var _t_para,para=(_t_para=this.getAttribute(arguments[0])||"").split(_t_para.indexOf("")>-1?"":"|");
		for (var i=0;i<Math.max(arguments.length-1,para.length);i++)
			para[i]=para[i]||arguments[i+1]||"";
		return para;
	};
	this.$r=this.$regEvent=function(eventList,funcList,hash,level){
		//eventList,funcList,hash,level
		//eventList,funcList,level
		level=level||50;
		if (arguments.length==3&&typeof hash=="number"){
			level=hash;
			hash=null;
		}
		var obj=this;
		if (eventList.constructor!=Array) eventList=[eventList];
		if (funcList.constructor!=Array) funcList=[funcList];
		eventList.each(function(e){
			funcList.each(function(f){
				e=e.replace(/^(on)?/i,"");
				e=e=="DOMContentLoaded"?"domready":e.toLowerCase();;
				if (e=="domready")
					obj=_;
				var eventInfo={
					enabled:true,
					obj:obj,
					event:e,
					func:f,
					hash:hash,
					level:level,
					id:_.$$.status.regEventCount++
				};
				if (e=="domready"&&$$.status.domReady||e=="load"&&(obj==_||obj==__.body)&&$$.status.load)
					f();
				else{
					if (!(e in obj.module.event)){
						obj.module.event[e]=[];
						if (obj.attachEvent) obj.attachEvent("on"+e,execEvent(obj));
						else obj.addEventListener(e,execEvent(obj),false);
					}
					obj.module.event[e].push(eventInfo);
					obj.module.event[e].sort(function(a,b){
						return (a.level-b.level)||(a.id-b.id);
					});
				}
				if (hash){
					if (!(hash in $$.status.regEventHash))
						$$.status.regEventHash[hash]=[];
					$$.status.regEventHash[hash].push(eventInfo);
				}
			});
		});
	};
	this.$ur=this.$unregEvent=function(eventList,funcList,hash){
		var obj=this;
		if (eventList.constructor!=Array) eventList=[eventList];
		if (funcList.constructor!=Array) funcList=[funcList];
		eventList.each(function(e){
			funcList.each(function(f){
				e=e.replace(/^(on)?/i,"");
				e=e=="DOMContentLoaded"?"domready":e.toLowerCase();
				if (e=="domready")
					obj=_;
				if (e in obj.module.event){
					var eventInfoList=obj.module.event[e];
					for (var i=0;i<eventInfoList.length;i++){
						if (eventInfoList[i].enabled&&eventInfoList[i].func==f&&(!hash||eventInfoList[i].hash==hash)){
							eventInfoList[i].enabled=false;
							break;
						}
					}
					if (!eventInfoList.length){
						delete obj.module.event[e];
						if (obj.detachEvent) obj.detachEvent(e,execEvent);
						else obj.removeEventListener(e,execEvent,false);
					}
				}
			});
		});
	};
	this.$urh=this.$unregEventHash=function(hash){
		var obj=this;
		if (hash in $$.status.regEventHash){
			var eventInfoList=$$.status.regEventHash[hash],eventInfo;
			while (eventInfo=eventInfoList.shift())
				eventInfo.obj.$ur(eventInfo.event,eventInfo.func,hash);
			delete $$.status.regEventHash[hash];
		}
	};
	this.$getWin=function(){
		var doc=this.ownerDocument;
		return doc.parentWindow||doc.defaultView;
	};

	this.$g=this.$selNode=function(sel){
		function _m_query(sel,node){
			var em=[],re=sel.match(/^([\.\#]*)([a-zA-Z0-9\-_*]+)(.*)$/i);
			if (!re) return [];
			if (re[1]=="#"){
				var objTmp=$(re[2]);
				if (objTmp) em.push(objTmp);
			}
			else if(re[1]==".")
				node.each(function(obj){
					obj.$("*").$each(function(obj){
						if (new RegExp("\\b"+re[2]+"\\b").test(obj.className))
							em.push($(obj));
					});
				});
			else
				for (var i=0;i<node.length;i++){
					var objTmp=node[i].$(re[2]);
					if (objTmp) for (var j=0;j<objTmp.length;j++) em.push(objTmp[j]);
				}
			re[3].replace(/\[([^!=]+)(=|!=)([^\]]*)\]/gi,function(a,b,c,d){
				var emTmp=em.slice(0);
				em=[];
				emTmp.each(function(obj){
					b={"class":"className","for":"htmlFor"}[b]||b;
					var attrTmp=obj[b]||obj.getAttribute(b);
					var flag;
					if (b=="className")
						flag=new RegExp("\\b"+d+"\\b").test(attrTmp);
					else
						flag=attrTmp==d;
					if ((c=="=")==flag)
						em.push($(obj));
				});
			});
			return em;
		}
		var selfEm=[this==_?_.__.body:this],arr1=[],arr2=[];
		sel.replace(/[^\[,]([^\[,]*(\[[^\]]*\])*)+/g,function(a){
			var em=selfEm.slice(0);
			a.replace(/(#|\*)/gi," $1").replace(/([^\^ ])\.(\w+)/gi,"$1[className=$2]").trim().split(/\s+/g).each(function(str){
				em=_m_query(str,em);
			});
			arr1=arr1.concat(em);
		});
		arr1.each(function(em){
			if (!em.__selNodeFlag__){
				em.__selNodeFlag__=true;
				arr2.push(em);
			}
		});
		arr2.each(function(em){
			em.__selNodeFlag__=false;
			if(em.hasAttribute("__selNodeFlag__"))
				em.removeAttribute("__selNodeFlag__");
		});
		return arr2.length==0?null:arr2;
	};
	this.$getPos=function(){
		var src=this,obj=this,w,pos=[0,0],flag,border={"thin":2,"medium":4,"thick":6};
		function fixBorder(){
			if (src==obj)
				return;
			function calcBorder(str){
				var value=/^(none|hidden)$/i.test(obj.$getStyle("border"+str+"Style"))?0:obj.$getStyle("border"+str+"Width");
				return border[value]||parseInt(value,10)||0;
			}
			pos[0]+=calcBorder("Left");
			pos[1]+=calcBorder("Top");
		}
		do{
			w=$(obj).$getWin();
			if (obj.tagName.match(/^(iframe|frameset)$/i))
				fixBorder();
			flag=-1;
			do{
				pos[0]+=obj.offsetLeft-obj.scrollLeft;
				pos[1]+=obj.offsetTop-($$.browser.Safari&&obj==w.document.body?0:obj.scrollTop);
				if ($$.browser.IE)
					fixBorder();
				if (!$$.browser.IE6&&obj.$getStyle("position")=="fixed")
					flag=1;
			} while(obj.offsetParent&&obj!=obj.offsetParent&&(obj=$(obj.offsetParent))&&obj!=_.___);
			if ($$.browser.Safari){
				pos[0]+=w.__.body.leftMargin||0;
				pos[1]+=w.__.body.topMargin||0;
			}
			if (flag==1||w!=$topWin){
				pos[0]+=w.___.scrollLeft*flag;
				pos[1]+=w.___.scrollTop*flag;
			}
			if (w==$topWin)
				break;
		} while (obj=w.frameElement);
		return pos;
	};
	this.$setPos=function(obj2,pos1,pos2){
		function _m_query(re,i){
			function _m_cal(pos,obj,px,i){
				return px+{"l":0,"c":obj.offsetWidth/2,"r":obj.offsetWidth,"t":0,"m":obj.offsetHeight/2,"b":obj.offsetHeight}[pos||"l"]*i;
			}
			return _m_cal(pos1.match(re),this,_m_cal(pos2.match(re),obj2,pos[i],1),-1)+"px";
		}
		var pos=obj2.$getPos();
		pos1=pos1||"lt";
		pos2=pos2||"lb";
		this.style.left=_m_query.call(this,/[lcr]/i,0);
		this.style.top=_m_query.call(this,/[tmb]/i,1);
	};
	this.$setIframe=function(flag){
		if (flag!==true&&!$$.browser.IE6) return;
		if (this.module.iframe)
			iframe=this.module.iframe;
		else{
			function getIframe(){
				for (var i=0;i<$topWin.$$.module.iframe.length;i++){
					if ($topWin.$$.module.iframe[i].$getStyle("display")=="none")
						return $topWin.$$.module.iframe[i];
				}
			}
			var iframe=getIframe();
			if (!iframe){
				iframe=$topWin.$c("iframe");
				with(iframe.style){
					width=height="0px";
					background="#FFF";
					position="absolute";
					display="none";
					zIndex=100;
				}
				iframe.frameBorder=0;
				iframe.id=iframe.name=$getUid();
				$topWin.$$.status.container.appendChild(iframe);
				$topWin.$$.module.iframe.push(iframe);
				with($topWin.frames[iframe.id].document){
					open();
					write('<style>html,body{overflow:hidden}</style>');
					close();
				}
			}
			this.module.iframe=iframe;
		}
		iframe.$setPos(this,"tl","tl");
		with (iframe.style){
			width=this.offsetWidth+"px";
			height=this.offsetHeight+"px";
			display="";
		}
		return iframe;
	};
	this.$clearIframe=function(){
		var iframe=this.module.iframe;
		if (iframe){
			iframe.style.display="none";
			this.module.iframe=null;
		}
		return iframe;
	};
	function $abs(obj,flag,func){
		if (!obj) return null;
		flag=flag||"n";
		var re=new RegExp(({1:"n",3:"t",8:"c"}[obj.nodeType])||"o","i");
		return flag.match(re)?obj:func.call(obj,flag);
	}
	this.$nAbs=function(flag){
		var obj=this,objTmp=obj.firstChild||obj.nextSibling;
		if (!objTmp)
			do {
				obj=obj.parentNode;
				if (obj==__.body) return null;
				objTmp=obj.nextSibling;
			} while (!objTmp);
		return $($abs(objTmp,flag,arguments.callee));
	};
	this.$pAbs=function(flag){
		if (this==__.body) return null;
		var objTmp=this.previousSibling;
		if (objTmp){
			while (objTmp.lastChild)
				objTmp=objTmp.lastChild;
		}else
			objTmp=this.parentNode;
		return $($abs(objTmp,flag,arguments.callee));
	};
	this.$focusNext=function(){
		if (!this.form) return;
		try{this.blur();}catch(e){;};
		var obj=this.form.elements,flag;
		for (var i=0;i<obj.length;i++){
			if (flag){
				if (!$(obj[i]).disabled&&obj[i].$isDisplay())
					try{obj[i].focus();return;}catch(e){};
			}
			if (obj[i]==this) flag=true;
		};
	};
	this.$setDisplay=function(){
		var pos=this.$getPos();
		with($topWin.___){
			scrollLeft=pos[0]-80;
			scrollTop=pos[1]-80;
		}
	};
	this.$isDisplay=function(){
		var obj=this;
		do {
			if (obj.tagName=="INPUT"&&obj.type=="hidden"||
				obj.$getStyle("display")=="none"||
				obj.$getStyle("visibility")=="hidden")
					return false;
		} while ((obj=obj.$parentNode())&&obj.nodeType==1);
		return true;
	};
	return this;
};

//初始化DOM节点
DOM.apply(_);
DOM.apply(__);
DOM.apply(___);
DOM.apply($$.status.alertDiv);


//初始化
(function(){
	_.$s2t=function(s){return s};

	//修正IE6背景图不缓存
	if ($$.browser.IE6)
		try{__.execCommand("BackgroundImageCache",false,true);}catch(e){;};

	//初始化debug
	$$.status.debug=/\$debug\$/i.test($topWin.name)||/^(true|1)$/.test($getQuery("debug"));
	$$.status.debugEvent=/\$debugEvent\$/i.test($topWin.name)||/^(true|1)$/.test($getQuery("debugEvent"));

	//初始化$alert函数
	$$.status.alertDiv.innerHTML=$$.status.version.match(/^zh-/)?"<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"base_popwindow01\"><tr><td class=\"base_poptl\"><\/td><td class=\"base_poptc\"><div><\/div><\/td><td class=\"base_poptr\"><\/td><\/tr><tr><td class=\"base_popml\"><\/td><td id=\"alertInfo\" class=\"base_popmc\">内容<\/td><td class=\"base_popmr\"><\/td><\/tr><tr><td class=\"base_popbl\"><\/td><td class=\"base_popbc\"><div><\/div><\/td><td class=\"base_popbr\"><\/td><\/tr><\/table>":"<table id=\"alertTable\" style=\"font-family:Arial;margin:0;\" cellpadding=\"0\" cellspacing=\"0\"><tr><td style=\"margin:0;padding:0px 2px 2px 0px;background:#E7E7E7;\"><div id=\"alertInfo\" style=\"margin:0px;padding:10px;font-size:12px;text-align:left;background:#FFFFE8;border:1px solid #FFDF47;color:#000;white-space:nowrap;\">内容<\/div><\/td><\/tr><\/table>";

	//初始化domReady事件
	function evtDomReady(e){
		function execEvent(){
			if ($$.status.domReady)
				return;
			var eventInfo;
			$$.status.domReady=true;
			if ("domready" in _.module.event){
				while (eventInfo=_.module.event["domready"].shift())
					if (eventInfo.enabled)
						try{eventInfo.func(e);}catch(e){
							$t("domReady函数错误:"+eventInfo.func.toString().slice(0,100)+"...","red",eventInfo.func);
							$trackEvent('tuna-error', 'evtDomReady.execEvent',$error(e), $tunaVersion());
						};
			}
		}
		if ($$.browser.Safari||$$.browser.Opera)
			setTimeout(execEvent,1);
		else
			execEvent();
	}

	//注册domReady事件
	if($$.browser.Moz)
		__.addEventListener("DOMContentLoaded",evtDomReady,false);
	else if($$.browser.IE){
		try{
			if (!_.frameElement)
				(function (){
					try {
						___.doScroll("left");
					}catch (e){
						setTimeout(arguments.callee,50);
						return;
					}
					evtDomReady();
				})();
		}catch(e){;};
	}else if($$.browser.Safari){
		var domReadyTimer=setInterval(function(){
			if(__.readyState=="loaded"||__.readyState=="complete"){
				clearInterval(domReadyTimer);
				evtDomReady();
			}
		},10); 
	}

	//加载页面变量
	function loadPageValue(){
		var str=$$.status.saveStatus.value;
		if (str)
			$$.status.back=true;
		$$.status.pageValue=$fromJson(str||"{}");
		if (!("data" in $$.status.pageValue))
			$$.status.pageValue.data={};
		if (!$$.browser.Opera)
			$r("beforeunload",[$saveHistory,$savePageValue],90);
	}

	//加载History
	function loadHistory(){
		($$.status.pageValue["historyInfo"]||"").split("|").each(function(info){
			var arr=unescape(info).split("|");
			if (arr.length==5){
				for (var i=0;i<arr.length;i++)
					arr[i]=unescape(arr[i]);
				$$.history.info[arr[0]]=arr.slice(1);
				$t("[history]恢复历史:"+arr[1]+"/"+arr[2],"green",arr.slice(2).join("\r"));
			}
		});
		$$.history.count=parseInt($$.status.pageValue["historyCount"]||0,10)||0;
	}

	$r("domReady",function(){
		$(__.body);
		loadPageValue();
		loadHistory();
		var url=$$.status.pageValue["lastHistory"];
		if (url)
			if ($$.browser.IE||$$.browser.Opera){
				$r("load",function(){
					setTimeout(function(){
						$$.history.init();
					},1);
				});
			}else
				$$.history.init();
	},10);
	$r("domready",[$parserRe,$fixElement,function(){
		try{__.body.focus();}catch(e){;};
	}]);
	$r("load",[evtDomReady,function(){
		$$.status.load=true;
	}]);
})();
