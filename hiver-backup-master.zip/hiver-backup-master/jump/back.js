//jmpInfoÄ£¿é
/*
 * Todo:
 * use tuna: module, add id
 * config: changable, explicit refresh
 * getPosition: scroll, visibility
 * 
 * Notice:
 * don't name inpage template #main, old template doing
 */
$$.module.jmpInfo = (function(){
	var getPosition = function(el){
		var p = $(el).$getPos();
		return {x: p[0], y: p[1]};
	};

	var setPosition = function(el, pos){
		if(!el) return;
		var st = el.style, left, top;
		if(pos){
			left = pos.x + 'px';
			top = pos.y + 'px';
		}else{
			left = '-10000px';
			top = '-10000px';
		}
		if(st.display != 'block') st.display = 'block';
		if(st.left != left) st.left = left;
		if(st.top != top) st.top = top;
	};
	
	var J = {
		logging: false,
		coloring: false,
		animating: false,
		fading: false,
		
		arrow: null,
		container: null,
		arrowRate: 0.5,
		
		current: null,
		next: null,
		
		popup: null,
		
		ani_box: null,
		log_box: null,
		
		timers: {
			show: 300,
			hide: 100,
			refresh: 200
		},
		
		array: {},
		template: {},

		//css_url: $webresourceUrl('/styles/control/tuna_071206/control_jmpinfo_tuna_071206.css'),
		css_loaded: false,
		
		load_timeout: 3000,
		
		template_dir: $webresourceUrl('/code/js/resource/jmpInfo_tuna/'),
		data_dir: $webresourceUrl('/code/js/resource/jmpInfo_tuna/'),
		
		common_callback: null,

		log: function(){
			if(!J.logging) return;
			var a = [].slice.call(arguments, 0);
			if(window.console){
				console.log(a.join(' '));
			}else{
				if(!J.console_box) J.console_box = J.make_box({
					left: '50%',
					top: '0px',
					font: 'normal 12px/16px verdana',
					color: 'red',
					border: '1px solid gray',
					padding: '4px'
				});
				J.console_box.appendChild(document.createElement('div')).innerHTML = a.join(' ').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\r\n?|\n/g, '<br />');
			}
		},
		color: function(el, color){
			if(J.coloring){
				el.style.backgroundColor = color;
				el.style.borderColor = color == 'red' ? '#000' : '';
			}
		},
		
		init: function(){
			J.popup = $("tuna_jmpinfo") || $('z1');
			J.popup.style.visibility = 'visible';
			setPosition(J.popup, null);
			___.$r('mouseover', J.mouseover);
		},
		test: function(el){
			return el.getAttribute('mod') && /(\||^)jmpInfo(\||$)/.test(el.getAttribute('mod'));
		},
		mouseover: function(e){
			var evt = e || window.event;
			var el = evt.target || evt.srcElement;
			if(el == J.ani_box) return;
			if(J.current){
				if(J.parent_of(J.current, el) || J.parent_of(J.popup, el)){
					J.clear_timer('hide');
					J.color(J.current, 'red');
					return;
				}
				J.set_hide();
			}
			if(J.next){
				if(J.parent_of(J.next, el)) return;
				J.clear_timer('show');
				J.color(J.next, '');
			}
			J.next = null;
			if(J.test(el)) J.set_show(el);
		},
		make_box: function(sty){
			var div = document.createElement('div');
			var arr = [];
			sty = $merge({
				position:'absolute',
				left:'-1000px',
				top:'-1000px'
			}, sty);
			for(var s in sty) arr.push(s + ':' + sty[s]);
			div.style.cssText = arr.join(';');
			return document.body.appendChild(div);
		},
		set_show: function(el){
			J.next = el;
			J.set_timer('show');
			J.color(J.next, 'pink');
			J.getInfo(J.next);
			J.fire_event('before-show', J.next);
		},
		set_hide: function(el){
			J.set_timer('hide');
			J.color(J.current, 'yellow');
			J.fire_event('before-hide', J.current);
		},
		set_timer: function(type, b_interval){
			var t = J.timers;
			if(!t['h_' + type]){
				t['h_' + type] = (!b_interval ? setTimeout : setInterval)(J['fn_' + type], t[type]);
				if(b_interval) J['fn_' + type]();
			}
		},
		clear_timer: function(type, b_interval){
			var t = J.timers;
			t['h_' + type] = (!b_interval ? clearTimeout : clearInterval)(t['h_' + type]) && null;
		},
		change_state: function(bshow){
			if(bshow){
				if(!J.next){
					J.log('fn_show: J.next is null');
					return;
				}
				J.clear_timer('show');
				J.current = J.next;
				J.next = null;
				J.color(J.current, 'red');
				J.set_timer('refresh', true);
				J.fire_event('show', J.current);
				J.popup.$setIframe();
			}else{
				if(!J.current){
					J.log('fn_hide: J.current is null');
					return;
				}
				J.clear_timer('hide');
				J.clear_timer('refresh', true);
				if(J.fading) J.fade(true, J.popup, true);
				else if(J.animating) J.animate(true, getPosition(J.popup), true);
				else setPosition(J.popup, null);
				J.color(J.current, '');
				J.fire_event('hide', J.current);
				J.popup.$clearIframe();
				J.current = null;
			}
		},

		fn_show: function(effect_over){
			J.change_state(true);
		},
		fn_hide: function(flag){
			J.change_state(false);
		},
		fn_refresh: function(){
			if(!J.current){
				J.log('J.current lost');
				return;
			}
			var info = J.getInfo(J.current);
			if(info.ready){
				J.set_html(J.popup, J.makeHtml(info));
				var pos = J.set_pos(J.current, J.popup, info.position);
				if(J.animating) J.animate(true, pos);
				else if(J.fading) J.fade(true, J.popup);
			}
		},
		
		parent_of: function(a, b){
			if(!a || !b) return false;
			while(b && a != b) b = b.parentNode;
			return a == b;
		},
		view_port: function(){
			var r = $pageSize('win');
			r.right = r.left + r.width;
			r.bottom = r.top + r.height;
			return r;
		},
		animate: function(ini, target, hidding){
			if(!J.ani_box) J.ani_box = J.ani_box = J.make_box({border:'1px solid #999'});
			if(ini === true){
				if(!hidding == J.animate__) return;
				J.animate__ = !hidding;
				J.popup.style.visibility = 'hidden';
				var src = getPosition(J.current);
				$animate(J.ani_box, {
					left: [src.x, target.x],
					top: [src.y, target.y],
					width: [J.current.offsetWidth, J.popup.offsetWidth],
					height: [J.current.offsetHeight, J.popup.offsetHeight]
				}, {
					duration: 240,
					callback: J.animate,
					reverse: hidding
				})
			}else{
				J.popup.style.visibility = 'visible';
				setPosition(J.ani_box, null);
			}
		},
		fade: function(ini, target, hidding){
			if(ini === true){
				if(!hidding == J.fade__) return;
				J.fade__ = !hidding;
				$animate(target, {opacity: [0, 1]},{
					duration: 240,
					callback: hidding ? J.fade : function(){},
					reverse: hidding
				});
			}else{
				setPosition(J.popup, null);
			}
		},
		
		set_html: function(el, html){
			if(J.current_html == html) return;
			el.innerHTML = J.current_html = html;
			$parserRe(el);
			var st = el.style;
			st.overflow = 'visible';
			st.width = '';
			st.width = el.scrollWidth + 'px';
			st.height = '';
			st.height = el.scrollHeight + 'px';
		},
		set_pos: function(a, b, ar){
			if(!a || !b){
				return null;
			}
			if(!a.offsetWidth || !a.offsetHeight){
				setPosition(b, null);
				if(b.$clearIframe) b.$clearIframe();
				return null;
			}else{
				var p = J.calc_pos(a, b, ar);
				setPosition(b, p);
				if(b.$setIframe) b.$setIframe();
				return p;
			}
		},
		set_arrow_pos: function(el, pos){
			if(pos[0])
				el.style.left = pos[0]+"px";
			if(pos[1])
				el.style.top = pos[1]+"px";
		},
		calc_class: function(ar, offset){
			if(ar[0] == ar[2]){
				
			}
			else if(ar[1] == ar[3]){
				
			}
			else{
				return;
			}
			J.set_arrow_pos(J.arrow, 
				[
					offset[1].x - offset[0].x ? 0 : Math.min(a.offsetWidth, b.offsetWidth)*J.arrowRate,
					offset[1].y - offset[0].y ? 0 : Math.min(a.offsetHeight, b.offsetHeight)*J.arrowRate
				] 
			);
		},
		calc_pos: function(a, b, ar){
			if(ar && ar.length == 4){
				for(var i = 0, br = []; i < ar.length; i ++){
					br[i] = /[lt]/.test(ar[i]) ? 0 : /[rb]/.test(ar[i]) ? 1 : 0.5;
				}
				var offset = [{
					x: b.offsetWidth * br[0],
					y: b.offsetHeight * br[1]
				}, {
					x: a.offsetWidth * br[2],
					y: a.offsetHeight * br[3]
				}];
				
				var apos = getPosition(a);
				return {
					x: apos.x + offset[1].x - offset[0].x, 
					y: apos.y + offset[1].y - offset[0].y
				};
			}
			else{
				var apos = getPosition(a);
				var view = J.view_port();
				var asize = {x: a.offsetWidth, y: a.offsetHeight};
				var bsize = {x: b.offsetWidth, y: b.offsetHeight};
				var r = ['l', 't', 'l', 'b'];
				if(apos.x + bsize.x > view.right && apos.x + asize.x - bsize.x >= view.left){
					r[0] = 'r';
					r[2] = 'r';
				}
				if(apos.y + asize.y + bsize.y > view.bottom && apos.y - bsize.y >= view.top){
					r[1] = 'b';
					r[3] = 't';
				}
				return arguments.callee(a, b, r);
			}
		},
		
		fire_event: function(type, el){
			if(J.common_callback) J.common_callback(type, el);
			var fn = J.getInfo(el).callback;
			if(fn) fn(type, el);
		},
			
		loadTemplate: function(name){
			/*
			if(!J.css_loaded){
				J.css_loaded = true;
				$loadCss(J.css_url);
			}
			*/
			
			var hash = $$.module.jmpInfo.template;
			if(hash.hasOwnProperty(name)) return !!hash[name];
			hash[name] = false;
			
			if(name.charAt(0) == '#'){
				var el = document.$g(name);
				if(!el){
					J.log('template element ' + name + ' not found');
				}else{
					hash[name] = J.htmlOf(el[0]);
					return true;
				}
			}else{
				var url = J.template_dir + name + '.js';
				$loadJs(url, 'gbk', function(timeout){
					if(timeout){
						J.log('J.loadTemplate timeout for ' + url);
						return true;
					}
				}, J.load_timeout);	
			}
			
			return false;
		},
		loadData: function(query){
			if(!query) return true;
			
			var name = query.name;
			var hash = $$.module.jmpInfo.array;
			if(hash.hasOwnProperty(name)) return !!hash[name];
			hash[name] = false;
			
			var url = J.data_dir + name + '_' + $$.status.charset + '.js';
			$loadJs(url, null, function(timeout){
				if(timeout){
					J.log('J.loadData timeout for ' + url);
					return true;
				}
			}, J.load_timeout);
			
			return false;
		},
		
		getInfo: function(el){
			var ret = {};
			
			var page = (el.getAttribute('mod_jmpInfo_page') || 'default_normal').split('?');
			ret.page = !/^#/.test(page[0]) ? page[0].replace(/\.asp$/i, '').toLowerCase() : page[0];
			ret.query = J.parseQuery(page.slice(1).join(''));
			ret.ready = J.loadTemplate(ret.page) && J.loadData(ret.query);
			
			var content = el.getAttribute('mod_jmpInfo_content') || '';
			ret.content = content.split('|');
			
			var position = el.getAttribute('mod_jmpInfo_position') || 'auto';
			if(position in J.posMap) position = J.posMap[position];
			ret.position = /[ltrbcm]{4}/.test(position) ? position.split('') : null;
			
			var callback = el.getAttribute('mod_jmpInfo_callback');
			if(callback && typeof(window[callback]) == 'function') ret.callback = window[callback];
			
			return ret;
		},
		posMap: {
			'align-center': 'ctcb',
			'align-left': 'ltlb',
			'corner-left': 'ltrb',
			'align-right': 'rtrb',
			'corner-right': 'rtlb',
			'above-align-left': 'lblt',
			'above-align-right': 'rbrt'
		},
		parseQuery: function(s){
			if(!s) return null;
			var a = s.split('=');
			if(a.length < 2) return null;
			return {
				name: a[0],
				value: a.slice(1).join('')
			};
		},
		queryData: function(query){
			var s = $$.module.jmpInfo.array[query.name];
			var v = '@' + query.value + '|';
			var i = s.indexOf(v) + 1;
			if(!i){
				J.log('queryData failure', query.name, query.value);
				return [];
			}
			return s.slice(i, s.indexOf('@', i)).split('|');
		},
		makeHtml: function(info){
			var s = $$.module.jmpInfo.template[info.page];
			var m = s.match(/<body.*?>([\s\S]+)<\/body>/i);
			s = (m ? m[1] : s).replace(/<!--[\s\S]*?-->/g, '');
			var o = {'para': info.content};
			if(info.query) o['array'] = J.queryData(info.query);
			return J.fillContent(s, o);
		},
		fillContent: function(html, arrays){
			var prefix = $keys(arrays).join('|');
			var s = '(<(\\w+)[^>]*)\\bid="(' + prefix + ')(\\d+)"([^>]*>)[\\s\\S]*?(<\\/\\2>)';
			var r = new RegExp(s, 'gi');
			return html.replace(r, function(x1, p1, x2, type, index, p2, p3){
				return p1 + p2 + (arrays[type][index - 1] || '') + p3;
			});
		},
		
		htmlOf: function(el){
			if(!el || el.nodeType != 1) return '';
			el = el.cloneNode(true);
			el.removeAttribute('id');
			el.style.cssText = el.style.cssText.replace(/\bdisplay:\s*none;?/i, '');
			if('outerHTML' in el){
				return el.outerHTML.replace(/(<[^>]+\sid=)(\w+)/g, '$1"$2"');
			}else{
				var r = [];
				var a = el.attributes;
				for(var i = 0; i < a.length; i++){
					if(a[i].name == 'id') continue;
					r.push(a[i].name + '="' + a[i].value + '"');
				}
				var s = r.length ? ' ' + r.join(' ') : '';
				var t = el.tagName.toLowerCase();
				return '<' + t + s + '>' + el.innerHTML + '</' + t + '>';
			}
		}
	};
	$r('domReady', J.init);
	return J;
})();

function posTri(tri, rectTar, rectPop, align){
	var als = align.join(''), m;
	if(m = als.match(/(.)b\1t|(.)t\1b/)){
		
	}
	else if(m = als.match(/(.)r\1l|(.)l\1r/)){
		
	}
	else{
		return false;
	}
	
	
	// got [dir, left, top]
	tri.className = (tri.className.replace(/\bbase_jmp_\w\s*/, '') + ' ' + dir).trim();
	tri.style.left = left + 'px';
	tri.style.top = top + 'px';
	return true;
}