$$.module.jmpInfo = {
	timers: {
		show: 300,
		hide: 150
	},
	
	container: $("tuna_jmpinfo") || $('z1'),
	template: {},
	array: {},
	
	load_timeout: 3000,
	
	template_dir: $webresourceUrl('/code/js/resource/jmpInfo_tuna/'),
	data_dir: $webresourceUrl('/code/js/resource/jmpInfo_tuna/')
};

(function(J){
var showTimer, current, ob = {}, cursor;
var posMap = {
	'align-center': 'ctcb',
	'align-left': 'ltlb',
	'corner-left': 'ltrb',
	'align-right': 'rtrb',
	'corner-right': 'rtlb',
	'above-align-left': 'lblt',
	'above-align-right': 'rbrt'
};

function JmpInfo(el){
	this.setInfo(el);
}
JmpInfo.prototype = {
	show: function(){
		var box = J.container;
		this.fillHtml(box, this.toHtml());
		
		this.setPosition(box, this.elem, this.position);
		if(box.$setIframe)
			box.$setIframe();
		this.countDownHide();
		if(typeof this.callback == 'function'){
			this.callback.call(null, 'show', this.elem);
		}
	},
	hide: function(){
		hide(J.container);
		current = null;
		if(J.container.$setIframe)
			J.container.$setIframe();
		if(typeof this.callback == 'function'){
			this.callback.call(null, 'hide', this.elem);
		}
	},
	setPosition: function(fl, target, po){
		//if(isVisiable(fl))
			//visiable(fl, false);
		show(fl);
		
		if(!(po && po.length == 2)){
			po = this.exchangeDirction(fl, target);
		}
		//visiable(fl, true);
		this.setPos(fl, target, po);
	},
	setPos: function(fl, target, po){
		fl.$setPos.apply(fl, [target].concat(po));
	},
	exchangeDirction: function(fl, target){
		var apos = target.$getPos();
		var view = this.view();
		var asize = { x: target.offsetWidth, y: target.offsetHeight };
		var bsize = { x: fl.offsetWidth, y: fl.offsetHeight };

		var r = ['l', 't', 'l', 'b'];
		if(apos[0] + bsize.x > view.right &&
			 apos[0] + asize.x - bsize.x >= view.left){
			r[0] = 'r';
			r[2] = 'r';
		}
		if(apos[1] + asize.y + bsize.y > view.bottom &&
			 apos[1] - bsize.y >= view.top){
			r[1] = 'b';
			r[3] = 't';
		}
		return [r.slice(0, -2).join(""), r.slice(2).join("")];
	},
	view: function(){
		var r = $pageSize('win');
		r.right = r.left + r.width;
		r.bottom = r.top + r.height;
		return r;
	},
	fillHtml: function(el, html){
		el.innerHTML = html;
		$parserRe(el);
	},
	getInfo: function(){},
	setInfo: function(el){
		this.elem = el;
		var page = (el.getAttribute('mod_jmpInfo_page') || 'default_normal').split('?');
		this.page = !(/^#/).test(page[0]) ? page[0].replace(/\.asp$/i, '').toLowerCase() : page[0];
		this.query = this.parseQuery(page.slice(1).join(''));
		this.ready = this.loadTemplate(this.page) && this.loadData(this.query);
		
		var content = el.getAttribute('mod_jmpInfo_content') || '';
		this.content = content.split('|');
		
		var position = el.getAttribute('mod_jmpInfo_position') || 'auto';
		if(position in posMap) position = posMap[position];
		this.position = position.match(/[ltrbc]{2}/ig);
		
		var callback = el.getAttribute('mod_jmpInfo_callback');
		if(callback && typeof(_[callback]) == 'function') this.callback = _[callback];

		return this;
	},
	toHtml: function(){
		var s = J.template[this.page];
		var m = s.match(/<body.*?>([\s\S]+)<\/body>/i);
		s = (m ? m[1] : s).replace(/<!--[\s\S]*?-->/g, '');
		var o = {'para': this.content};
		if(this.query)
			o['array'] = this.queryData(this.query);
		return this.fillContent(s, o);
	},
	parseQuery: function(s){
		if(!s) return null;
		var a = s.split('=');
		if(a.length < 2) return null;
		return {
			name: a[0],
			value: a.slice(1).join('')
		};
	},
	loadData: function(query){
		if(!query) return true;
		
		var name = query.name;
		var hash = J.array;
		if(hash.hasOwnProperty(name)) return !!hash[name];
		hash[name] = false;
		
		var url = J.data_dir + name + '_' + $$.status.charset + '.js';
		$loadJs(url, null, function(timeout){
			if(timeout)
				return true;
		}, J.load_timeout);
		
		return false;
	},
	loadTemplate: function(name){
		var hash = J.template;
		if(hash.hasOwnProperty(name))
		 	return !!hash[name];
		hash[name] = false;
		
		if(name.charAt(0) === '#'){
			var el = __.$g(name);
			if(el){
				hash[name] = this.htmlOf(el[0]);
				return true;
			}
		}else{
			var url = J.template_dir + name + '.js';
			$loadJs(url, 'gbk', function(timeout){
				if(timeout)
					return true;
			}, J.load_timeout);	
		}
		
		return false;
	},
	htmlOf: function(el){
		if(!el || el.nodeType != 1) return '';
		el = el.cloneNode(true);
		el.removeAttribute('id');
		el.style.cssText = el.style.cssText.replace(/\bdisplay:\s*none;?/i, '');
		if('outerHTML' in el){
			return el.outerHTML.replace(/(<[^>]+\sid=)(\w+)/g, '$1"$2"');
		}else{
			var r = [];
			var a = el.attributes;
			for(var i = 0; i < a.length; i++){
				if(a[i].name == 'id') continue;
				r.push(a[i].name + '="' + a[i].value + '"');
			}
			var s = r.length ? ' ' + r.join(' ') : '';
			var t = el.tagName.toLowerCase();
			return '<' + t + s + '>' + el.innerHTML + '</' + t + '>';
		}
	},
	fillContent: function(html, arrays){
		var prefix = $keys(arrays).join('|');
		var s = '(<(\\w+)[^>]*)\\bid="(' + prefix + ')(\\d+)"([^>]*>)[\\s\\S]*?(<\\/\\2>)';
		var r = new RegExp(s, 'gi');
		return html.replace(r, function(x1, p1, x2, type, index, p2, p3){
			return p1 + p2 + (arrays[type][index - 1] || '') + p3;
		});
	},
	countDownHide: function(){
		var _this = this;
		var timer = setInterval(function(){
			if(current && contains(current, cursor) 
				|| contains(J.container, cursor))
				return;
			
			_this.hide();
			clearInterval(timer);
		}, J.timers.hide);
	}
};
function JmpInfo2(el){
	this.direct = {
		't':(/(.)t\1b/),
		'r':(/r(.)l\1/),
		'b':(/(.)b\1t/),
		'l':(/l(.)r\1/)
	};
	this.box = null;
	this.arrow = null;
	JmpInfo.call(this, el);
}
__extend(JmpInfo2, JmpInfo);
$extend(JmpInfo2.prototype, {
	fillHtml: function(el, html){
		JmpInfo.prototype.fillHtml.call(this, el, html);
		this.box = J.container.$g(".base_jmp")[0];
		this.arrow = J.container.$("b")[0];
	},
	setPos: function(fl, target, po){
		var tmp = po.join("");
		this.exchangeClass(fl, target, tmp);
		fl.$setPos.apply(fl, [target].concat(po));
	},
	exchangeClass: function(fl, target, po){
		for(k in this.direct){
			var m = po.match(this.direct[k]);
			if(m){
				this.box.className = this.box.className.replace(/[trbl]$/, k);
				this.arrow.className = this.arrow.className.replace(/[trbl]$/, k);
				this.calculateArrow(fl, target, k, m[1]);
				return;
			}
		}
		alert('This direction no support yet!!');
	},
	calculateArrow: function(fl, target, k, m){
		if('tb'.indexOf(k) >= 0){
			var w1 = fl.offsetWidth,
				w2 = target.offsetWidth;
			if(m === 'l'){
				this.arrow.style.left = Math.min(w1, w2)/2 + "px";
			}
			else if(m === 'r'){
				this.arrow.style.right = Math.min(w1, w2)/2 + "px";
			}
		}
	}
});
	
var contains = __.compareDocumentPosition ? function(a, b){
    return a == b || !!(a.compareDocumentPosition(b) & 16);
} : function(a, b){
    return (a.contains ? a.contains(b) : true);
};

function __extend(b, p){
    var F = function(){};
    F.prototype = p.prototype;
    b.prototype = new F();
    b.prototype.constructor = b;
}

function hide(el){
	el.style.display = "none";
}

function show(el){
	el.style.display = "";
}

function visiable(el, bol){
	el.style.visibility = bol ? "" : "hidden";
}

function isVisiable(el){
	return !(el.style.visibility == "hidden");
}

function countDownShow(el){
	if(showTimer)
		clearTimeout(showTimer);
	showTimer = setTimeout(function(){
		if(!(current && contains(current, cursor)))
			return;
		initJmpInfo(el);
	}, J.timers.show);
}

function configType(el, type){
	var temp = ob[type]; 
	if(temp){
		temp.setInfo(el);
	}
	else{
		switch(type){
			case "jmpinfo":
				temp = new JmpInfo(el);
			break;
			case "jmpinfo2":
				temp = new JmpInfo2(el);
			break;
			default:
				alert("no this type yet!");
			break;
		}
	}
	return temp;
}

function initJmpInfo(el){
	var mod = el.getAttribute("mod");
	var type = mod.match(/(\||^)(jmpInfo\d*)(\||$)/i)[2].toLowerCase();
	var tp = configType(el, type);
	
	tp.show();
}

function handleMouseOver(e){
	//没有备份，当前的。
	var tar = cursor = $fixE(e).$target;
	var jmp = isJmp(tar);
	if(jmp){
		if(current && contains(current, tar))
			return;
		countDownShow(jmp);
		current = jmp;
	}
	else{
		current = null;
	}
}

function isJmp(el){
	while(!hasJmpInfo(el) && ___ != el){
		el = el.parentNode;
	}
	return el == ___ ? null : $(el);
}

function hasJmpInfo(el){
	if(!el.getAttribute)
		return false;
	var attr = el.getAttribute("mod");
	return attr && (/(\||^)jmpInfo\d*(\||$)/i).test(attr);
}

(function init(){
	if(!isVisiable(J.container))
		J.container.style.visibility = "";
	if(J.container && J.container.$isDisplay())
		hide(J.container);
	
	___.$r('mouseover', handleMouseOver);
	_.$r('unload', function(){
		___.$ur('mouseover', handleMouseOver);
		_.$ur('unload', arguments.callee);
	});
})();
})($$.module.jmpInfo);