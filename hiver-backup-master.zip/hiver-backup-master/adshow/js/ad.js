if(!_.AD)
    _.AD = {};

AD.config1 = {
    box:"adshow1",
    spliter:["\n", "|"],
    current:1,
    perHeight:200,
    idFix:1,
    auto:10000
};

AD.config2 = {
    box:"adshow2",
    spliter:["\n", "|"],
    current:1,
    perHeight:200,
    idFix:2,
    auto:10000
};

AD.config3 = {
    box:"adshow3",
    spliter:["\n", "|"],
    current:1,
    perHeight:200,
    idFix:3,
    auto:10000
};

AD.extend = function(b, p){
    var F = function(){};
    F.prototype = p.prototype;
    b.prototype = new F();
    b.prototype.constructor = b;
    
    b.superClass = p.prototype;  
    if(p.prototype.constructor == Object.prototype.constructor)  
        p.prototype.constructor = p;
}

AD.base = function(config){
    this._init(config);
}
AD.base.prototype = {
    _init:function(config){
        this._box = $(config.box);
        this._raw = this._box.$("textarea")[0].value;
        this._spliter = config.spliter;
        this._current = config.current;
        this._perHeight = config.perHeight;
        this._data = [];
        this._idFix = config.idFix;
        this._auto = config.auto;
        this._timer = null;
        this._timer2 = null;
        this._load = 0;
        this._imgs = [];
        this._btns = [];
        this._arrows = [];
        this._initialize();
    },
    _transfor:function(raw){
        var arr = raw.trim().split(this._spliter[0]);
        arr.each(function(item, i){
            var o = this._trans(item);
            if(o){
                this._data.push(o);
            }
        }.bind(this));
    },
    _trans:function(ss){
        if(!ss.trim())
            return null;
        var oo = {};
        var aa = ss.split(this._spliter[1]);
        oo.src = aa[0].trim();
        oo.href = aa[1].trim();
        oo.text = aa[2].trim();
        oo.alt = aa[3].trim();
        return oo;
    },
    _initialize:function(){
        this._transfor(this._raw);
        this._template = {
            main:'<div class="adshow-window"  id="adshow_win{$prefix}">\
                <div id="adshow_window{$prefix}" style="{$winStyle}" class="adshow-opacity">{$windows}</div>\
            </div>\
            <div id="adshow_bar{$prefix}" class="adshow-bar">{$bars}</div>',
            win:'<a target="_blank" href="{$href}"><img alt="" /></a>',
            btn:'<div><span class="arrow" style="{$arrowStyle}"></span><a class="{$barClass}" href="javascript:void(0);">{$text}</a></div>'
        };
        this._box.innerHTML = this._drawStruct();
        this._imgs = $("adshow_window"+this._idFix).$("img");
        this._btns = $("adshow_bar"+this._idFix).$("a");
        this._arrows = $("adshow_bar"+this._idFix).$("span");
        this._scroll = $("adshow_win"+this._idFix);
        this._setImgZIndex(this._imgs[this._current], 999);
        this._preLoadImg();
        this._attachEvents();
        this._setAuto();
    },
    _resetZIndex:function(i){
        this._imgs.$each(function(item){
            item.parentNode.style.zIndex = 99;
        });
    },
    _setCurrent:function(i){
        this._hideArrow(this._current);
        this._hideBtn(this._current);
        this._resetZIndex();
        this._setImgZIndex(this._imgs[this._current], 100);
        this._current = i;
        this._showArrow(i);
        this._showBtn(i);
        this._setImgZIndex(this._imgs[i], 999);
        this._setAuto();
    },
    _showArrow:function(i){
        $animate(this._arrows[i], {'marginLeft':[this._arrows[i].style.marginLeft.replace("px","")|0,-5]},{duration:200});
    },
    _hideArrow:function(i){
        $animate(this._arrows[i], {'marginLeft':[this._arrows[i].style.marginLeft.replace("px","")|0,0]},{duration:200});
    },
    _hideBtn:function(i){
        this._btns[i].className = this._btns[i].className.replace("current", "uncurrent");
    },
    _showBtn:function(i){
        this._btns[i].className = this._btns[i].className.replace("uncurrent", "current");
    },
    _setImgZIndex:function(el, no){
        el.parentNode.style.zIndex = no;
    },
    _attachEvents:function(){
        var _this = this;
        this._btns.$each(function(item, i){
            item.$r("mousedown", function(e){
                e = $fixE(e); e.preventDefault?e.preventDefault():(e.returnValue=false);
                if(_this._current == i)
                    return;
                _this._setCurrent(i);
            });
            item.onfocus = function(){this.blur()};
        });
    },
    _drawStruct:function(){
        var a = this._drawParts();
        return this._template.main.replaceWith({
            winStyle:"height:200px",
            windows:a[1],
            bars:a[0],
            prefix:this._idFix
        });
    },
    _drawParts:function(){
        var bs = [], ws = [];
        for(var i = 0; i < this._data.length; i++){
            var barClass = "";
            if(i === 0){
                barClass = "top-uncurrent";
            }
            else if(i === this._data.length-1){
                barClass = "btm-uncurrent";
            }
            else {
                barClass = "mid-uncurrent";
            }

            bs.push(this._template.btn.replaceWith({
                barClass: i === this._current ? barClass.replace('uncurrent', 'current') : barClass,
                text:this._data[i].text,
                arrowStyle: i === this._current ? "margin-left:-5px" : ""
            }));
            
            ws.push(this._template.win.replaceWith({
                href:this._data[i].href,
                alt:this._data[i].alt
            }));
        }
        return [bs.join(""), ws.join("")];
    },
    _preLoadImg:function(){
        var _this = this;
        for(var i = 0; i < this._data.length; i++){
            (function(i){
                var img = document.createElement("img");
                img.onload = function(){
                    _this._imgs[i].src = img.src;
                    _this._load++;
                    if(_this._load == _this._data.length)
                        _this._preLoadCallback();
                };
                img.src = _this._data[i].src;
            })(i);
        }
    },
    _setAuto:function(){
        if(!this._auto)
            return;
        if(this._timer2)
            clearTimeout(this._timer2);
            
        var _this = this;
        var next = this._current == this._data.length-1 ? 0 : this._current+1;
        this._timer2 = setTimeout(function(){
            _this._setCurrent(next);
        }, this._auto);
    },
    _preLoadCallback:function(){}
}

AD.scroll = function(config){
    AD.scroll.superClass.constructor.call(this, config);
}

AD.extend(AD.scroll, AD.base);

$extend(AD.scroll.prototype, {
    _initialize:function(){
        AD.scroll.superClass._initialize.call(this);
        this._template = {
            main:'<div class="adshow-window"  id="adshow_win{$prefix}">\
                <div id="adshow_window{$prefix}" style="{$winStyle}">{$windows}</div>\
            </div>\
            <div id="adshow_bar{$prefix}" class="adshow-bar">{$bars}</div>',
            win:'<a target="_blank" href="{$href}"><img alt="" /></a>',
            btn:'<div><span class="arrow" style="{$arrowStyle}"></span><a class="{$barClass}" href="javascript:void(0);">{$text}</a></div>'
        };
        this._box.innerHTML = this._drawStruct();
        this._imgs = $("adshow_window"+this._idFix).$("img");
        this._btns = $("adshow_bar"+this._idFix).$("a");
        this._arrows = $("adshow_bar"+this._idFix).$("span");
        this._scroll = $("adshow_win"+this._idFix);
        this._scroll.scrollTop = this._perHeight * this._current;
        this._preLoadImg();
        this._attachEvents();
        this._setAuto();
    },
    _setCurrent:function(i){
        this._hideArrow(this._current);
        this._hideBtn(this._current);
        this._current = i;
        this._showArrow(i);
        this._showBtn(i);
        this._scrollTo(i);
        this._setAuto();
    },
    _scrollTo:function(i){
        if(this._timer){
            clearInterval(this._timer);
        }
        var top = this._perHeight * i;
        var now = this._scroll.scrollTop;
        this._timer = $animate2([[this._scroll, {scrollTop:[now, top, 0]}]],{duration:300});
    },
    _drawStruct:function(){
        var a = this._drawParts();
        return this._template.main.replaceWith({
            winStyle:"height:"+this._data.length*this.perHeight+"px;",
            windows:a[1],
            bars:a[0],
            prefix:this._idFix
        });
    }
});

AD.opacity = function(config){
    AD.opacity.superClass.constructor.call(this, config);
}

AD.extend(AD.opacity, AD.base);

$extend(AD.opacity.prototype, {
    _setCurrent:function(i){
        this._hideArrow(this._current);
        this._hideBtn(this._current);
        this._resetZIndex();
        this._setImgZIndex(this._imgs[this._current], 100);
        this._current = i;
        this._showArrow(i);
        this._showBtn(i);
        this._setOpacity(this._imgs[i].parentNode, 0);
        this._setImgZIndex(this._imgs[i], 999);
        this._animateOpacity(this._imgs[this._current].parentNode);
        this._setAuto();
    },
    _animateOpacity:function(el){
        if(this._timer){
            clearInterval(this._timer);
        }
        var duration = 300;
        var no = 25;
        var start = new Date;
        var _this = this;
        this._timer = setInterval(function(){
            var d = new Date - start;
            if(d > duration)
                d = duration;
            
            var r = d/duration;
            _this._setOpacity(el, 100*r);
            
            if(d === duration){
                clearInterval(_this._timer);
            }
        }, no);
    },
    _setOpacity:function(t, n){
        if (/MSIE/.test(navigator.userAgent))
            t.style.filter = 'alpha(opacity='+n+')';
        else
            t.style.opacity = n/100;
    }
});


_.$r("domready",function(){
    AD.instanceScroll = new AD.scroll(AD.config1);
    AD.instanceOpacity = new AD.opacity(AD.config2);
    AD.instanceBase =  new AD.base(AD.config3);
});