(function(){
var POS = {
    center:{top:169,left:169},
    yCenter:{top:169,left:169},
    yR : 30,
    mCenter:{top:169,left:249},
    mR : 20,
    dCenter:{top:169,left:305},
    dR : 12,
    MR : 108,
    DR : 165,
    
    maskerBigCenter:{top:169,left:169},
    maskerBigR:50,
    maskerSmallCenter:{top:169,left:305},
    maskerSmallR:40,
    
    echelon:[
        {top:119,left:169},
        {top:131,left:305},
        {top:207,left:305},
        {top:219,left:169}
    ]
    
};

var targetHook = {
    "year":function(){},
    "month":function(){},
    "date":function(){},
    "masker":function(){},
    "monthpicker":monthpickerHandler,
    "datepicker":datepickerHandler
}

var animateHook = {
    "monthpicker":monthpickerHook,
    "datepicker":datepickerHook
};

window.Now = {
    year:'2010',
    month:'7',
    date:'10'
}

var render = '#test';



function main(){
    var now = Now;
    var coordinate = $("#eventpicker").offset();
    
    $("#eventpicker").bind("mousedown", function(e){
        e.preventDefault();
        var target = getTarget(e.pageX-coordinate.left, e.pageY-coordinate.top);
        
        if(!target)
            return;
        targetHook[target].call(null, {left:e.pageX, top:e.pageY}, target, coordinate);
    })
    .bind("mousemove",function(e){
        e.preventDefault();
        var target = getTarget(e.pageX-coordinate.left, e.pageY-coordinate.top);
        if(!target || target == "masker"){
            $(this).css("cursor","default");
        }
        else{
            $(this).css("cursor","pointer");
        }
    });
    
    drawYear(now.year);
    drawMonth(now.month);
    drawDate(now);
    $(render).val(formateDate(now));
}

function formateDate(now){
    return "{$year}-{$month}-{$date}".replaceWith(now);
}

function datepickerHandler(start, target, lt){
    initMousemove(target, $("#datepicker"), start, lt);
}

function monthpickerHandler(start, target, lt){
    initMousemove(target, $("#monthpicker"), start, lt);
}

function initMousemove(tar, container, start, lt){
    var cen = POS.center;
    var startDeg = getRate({left:start.left-lt.left, top:start.top-lt.top}, cen);
    var last = 0;
    var dis = 0;
    
    $("#eventpicker").bind("mousemove",handleMousemove);
    function handleMousemove(e){
        var end = {left:e.pageX-lt.left, top:e.pageY-lt.top}
        var endDeg = getRate(end, cen);
        dis = +(startDeg - endDeg).toFixed(2);
        
        if(dis == last)
            return;
        
        switch(tar){
            case "datepicker":
                redraw(dis, false, container);
                break;
            case "monthpicker":
                redraw(dis, false, container);
                break;
            default:
                
        }
        last = dis;
    }
    $(document).bind("mouseup", function(){
        $("#eventpicker").unbind("mousemove",handleMousemove);
        var cur = Math.round(dis/container.attr("pdeg"));
        var current = container.attr("current");
        var ll = +container.attr("leng");
        var xx = parseInt(current)+cur;
        if(xx > ll){
            xx -= ll;
        }
        else if(xx <= 0){
            xx += ll;
        }
        container.attr("current", xx);
        
        var leng = dis - cur*container.attr("pdeg");
        var per = leng/3, flag = 0;
        var timer = setInterval(function(){
            flag++;
            if(flag == 3){
                clearInterval(timer);
                redraw(dis-per*flag, true, container);
            }
            else{
                redraw(dis-per*flag, false, container);
            }
        },10);
        
        switch(tar){
            case "datepicker":
                Now.date = xx;
                break;
            case "monthpicker":
                Now.month = xx;
                break;
            default:
                
        }
        
        $(this).unbind("mouseup");
    });
}

function getTarget(x, y){
    var obt = {left:x,top:y};
    var yR = mathDis(POS.yCenter, obt);
    if(yR <= POS.yR){return "year";};
    
    var mR = mathDis(POS.mCenter, obt);
    if(mR <= POS.mR){return "month"};
    
    var dR = mathDis(POS.dCenter, obt);
    if(dR <= POS.dR){return "date"};
    
    
    
    var maskerBigR= mathDis(POS.maskerBigCenter, obt);
    if(maskerBigR <= POS.maskerBigR){
        return "masker";
    }
    
    var maskerSmallR= mathDis(POS.maskerSmallCenter, obt);
    if(maskerSmallR <= POS.maskerSmallR){
        return "masker";
    }
    
    if(isInEchelon(POS.echelon, obt)){
        return "masker";
    }
    
    var MR = mathDis(POS.center, obt);
    if(MR <= POS.MR){
        return "monthpicker";
    }
    
    var DR = mathDis(POS.center, obt);
    if(DR <= POS.DR){
        return "datepicker";
    }
}

function isInEchelon(list, point){
    var len = list.length;
    for(var i = len-1; i >= 0; i--){
        var n, o = list[i];
        if(i <= 0)
            n = len - 1;
        else
            n = i - 1;
        var a = getRate(point, o),b = getRate(list[n], o);
        if(a < b || Math.abs(a - b) >= Math.PI)
            return false;
    }
    return true;
}

function getRate(a,o){
    var x = a.left - o.left;
    var y = o.top - a.top;
    
    if(x<0){
        return Math.PI + Math.atan(y/x);
    }
    else if(x>=0 && y<0){
        return 2*Math.PI + Math.atan(y/x);
    }
    else{
        return Math.atan(y/x);
    }
}


function mathDis(a,b){
    return Math.round(Math.pow(Math.pow(a.left-b.left,2)+Math.pow(a.top-b.top,2),0.5));
}

function testCenter(o){
    var div = document.createElement("div");
    div.style.cssText = "height:1px;z-index:900;width:1px;background-color:red;overflow:hidden;position:absolute;top:"+o.top+"px;left:"+o.left+"px";
    
}

function drawYear(dd){
    $("#yearpicker").html(dd);
}

function drawMonth(dd){
    var html = [];
    var d = dd;
    for (var i = 0; i < 12; i++){
        if(dd < 1)
            dd = 12;
        html.push(createText(i, dd, 12, mathDis(POS.mCenter, POS.center), POS.center, 30));
        dd--;
    }
    $('#monthpicker').html(html.join(""))
    .attr("pdeg",2*Math.PI/12)
    .attr("current", d)
    .attr("r", mathDis(POS.mCenter, POS.center))
    .attr("leng",12);
}

function drawDate(dd){
    var html = [];
    var y = dd.year;
    var m = dd.month;
    var days = [31, y%4 || y%400 && !y%100 ? 28 : 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m-1];
    var d = dd.date;
    
    if(days == $('#datepicker').attr('leng'))
        return;

    while(d > days){
        d--;
    }
    for (var i = 0; i < days; i++){
        html.push(createText(i, d, days, mathDis(POS.dCenter, POS.center), POS.center, 30));
        d--;
        if(d < 1)
            d = days;
    }
    dd.date = d;
    $('#datepicker')
    .html(html.join(""))
    .attr("pdeg",2*Math.PI/days)
    .attr("current", dd.date)
    .attr("r", mathDis(POS.dCenter, POS.center))
    .attr("leng",days);
}

function redraw(deg, update, box){
    var center = POS.center;    
    var current = box.attr("current");
    var r = box.attr("r");
    var size = box.attr("size");
    $('span', box).each(function(i, item){
        var d = +$(this).attr('deg');
        var size = $(this).attr("size");
        $(this).css("left",center.left+r*Math.cos(deg+d)-size/2+"px")
        .css("top",center.top+r*Math.sin(deg+d)-size/2+"px");
        if(update){
            var x = d+deg;
            if(x > 2*Math.PI)
                x -= 2*Math.PI;
            $(this).attr("deg",x);
            animateHook[box.selector.replace("#","")].call(null);
        }
    });
}

function monthpickerHook(){
    drawDate(Now);
    $(render).val(formateDate(Now));
}

function datepickerHook(){
    $(render).val(formateDate(Now));
}

function createText(i, current, no, R, center, size){
    var deg = 2*Math.PI*i/no;
    var obt = {
        left:center.left + R*Math.cos(deg) - size/2 +"px",
        top:center.top + R*Math.sin(deg) - size/2 + "px",
        current:current,
        deg:deg,
        size:size
    };

    return "<span size='{$size}' deg='{$deg}' style='left:{$left};top:{$top};'>{$current}</span>".replaceWith(obt);
}


String.prototype.replaceWith = function(obj){
    return this.replace(/\{\$(\w+)\}/g,function(s,k){
        if(k in obj)
            return obj[k];
        else
            return s;
    });
}
$(main);

})();