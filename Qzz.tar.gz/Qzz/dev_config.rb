# -*- encoding : utf-8 -*- 
require 'rubygems'
require 'yaml'

=begin
.dev配置文件格式

	dev:
		host: 59.151.51.42
		path: /server/qunarzz.com/
	dev2: 
		host: 59.151.51.42
		path: /server/qunarzz.com/
	
=end

class DevConfig

	attr_accessor :data
	
	def initialize( path )
		if File.exist?( path ) 
			@data = YAML.load_file path
		else
			puts "没有找到#{path}"
		end
	end
	
end