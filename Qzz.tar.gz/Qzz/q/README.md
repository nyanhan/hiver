cd to/your/qzz/folder # 只需要第一次

node path/to/lib/qserver.js

-p 指定端口 -r reset 根目录
