# -*- encoding : utf-8 -*- 
require "pathname"

def joinFile( p1 , p2 )
	p = Pathname.new( File.join( p1 , p2 ) )
	p.cleanpath.to_s
end

def extractor_file( file , &block )
	lines = []
	readline_file( file ).each do |line|
		if block_given?
			n = block.call(line)
			lines << n if n
		end
	end
	lines
end

def readline_file( file )	
	data = []
	f = File.open( file , "r") 
	f.each_line do |line|
		data << line.strip << %q{
}			
	end
	return data
end

def readline_file_with_space( file )	
	data = []
	f = File.open( file , "r") 
	f.each_line do |line|
		data << line
	end
	return data
end


def read_file( file )
	data = ''
	f = File.open( file , "r") 
	f.each_line do |line|
		data += line
	end
	return data
end

def keycode_newline
%q{
}
end

def write_file( file , text , &block )
	puts "写入文件 -> #{file}"
	File.open( file , 'w' ) do |file|
		file.write(text)
		yield if block_given?
	end 
end

def os_family
	case RUBY_PLATFORM
		when /ix/i, /ux/i, /gnu/i,
			 /sysv/i, /solaris/i,
			 /sunos/i, /bsd/i, /darwin/i
		  "unix"
		when /win/i, /ming/i
		  "windows"
		else
		  "other"
	end
end

def replaceSplitSymbol( path_str )
	case os_family
		when "unix"
			return path_str.gsub "\\", "/"
		when "other"
			return path_str.gsub "\\", "/"
		when "windows"
			return path_str.gsub "/", "\\"
	end
end

def do_cmd( cmd )
	puts cmd
	puts `#{cmd}`
end

#如果是windows，则变更编码为gbk
if os_family == "windows"
    require 'iconv'
    def puts( *args )	
	    line = %q{
}
        str = args.join("")
	    cov = Iconv.new('gbk','utf-8')
		begin
			$stdout << cov.iconv(str) << line
		rescue
			$stdout << str << line
		end
    end
end
