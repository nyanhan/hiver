# -*- encoding : utf-8 -*- 
require 'rubygems'
require 'yaml'

class HostItem

	@@IP_REGEX = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/

	attr_accessor :ip , :host , :enable , :group
	
	def initialize( line , group ) 
		@ip = @@IP_REGEX.match( line )[0].strip
		@host = line.gsub( @@IP_REGEX , '' ).gsub(/#/,'').strip.split(/\s+/)
		@enable = ( line.strip.to_s[0,1] != '#' )
		
		@group = group
		
		if group
			group[:items] << self
		end
		
	end
	
	def group=( group ) 
		if @group
			@group[:items].delete( self )
		end
		@group = group
		if group && !group[:items].include?( self )
			group[:items] << self
		end
	end
	
	def is?( ip_or_host )
		return true if ip_or_host.nil?
		( @ip == ip_or_host ) || ( host.join(' ').include? ip_or_host )
	end
	
	def to_s 
		line = ""		
		if @enable == false
			line << "# "
		end
		line << @ip
		line << "\t"
		line << @host.join('  ')
		line
	end
	
	def inspect
		g = "none"
		g = @group[:name] if @group 
		{ "group" => g , "ip" => @ip , "enable" => @enable , "host" => @host }.inspect
	end
	
	def print
		g = "none"
		g = @group[:name] if @group 
		{ "enable" => @enable , "host" => "#{@ip} #{@host.join ' '}" }.inspect
	end
end

class HostConfig
	
	@@IP_REGEX = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/
	@@GRP_REGEX = /#\s*\[\s*(.*?)\s*\].*/
	
	attr_accessor :groups , :items
	
	def initialize
		@groups = []
		@items = []
		@file = readline_file( get_host_path )
		current_group = nil
		__safe__ = { :name => "__safe__" , :items => [] }
		
		@file.each do |line|
			line = line.strip.gsub(/#+/,'#')
			if @@IP_REGEX =~ line			#item
				if current_group.nil?
					current_group = __safe__
					@groups << __safe__
				end
				item = HostItem.new line , current_group
				@items << item
			elsif @@GRP_REGEX =~ line 		#group
				name = @@GRP_REGEX.match( line )[1] 
				current_group = { :name => name , :items => [] }
				@groups << current_group 
			end
		end 
	end
	
	def get_group( group_name )
		group_name = group_name || "__safe__"
		g = @groups.find { |gr| gr[:name] == group_name }
		unless g
			g = { :name => group_name , :items => [] }
			@groups << g
		end
		g
	end
	
	def get_by_group( group_name )
		group_name = group_name || "__safe__"
		g = @groups.find { |gr| gr[:name] == group_name }
		unless g
			g = { :name => group_name , :items => [] }
		end
		g
	end
	
	def remove_group( group_name )
	  return unless group_name
	  g = @groups.delete_if { |gr| gr[:name] == group_name } 
	  g
	end
	
	def add( ip , host , group , &block )
	
		if ip.nil? || host.nil?
			yield "请填写ip与host" if block_given?
			return
		end
		
		unless ip =~ @@IP_REGEX
			yield "错误的ip配置" if block_given?
			return
		end
		
		result = search ip
		if result.empty? 
			g = get_group( group )
			item = HostItem.new "#{ip} #{host}" , g
			@items << item
		else
			result.each { |item|
				unless item.host.join(',').include? host 
					item.host << host 
				end
				item.group = get_group( group )
			}
		end
		save
		yield "完成添加" if block_given?
		
	end
	
	def save  
		text = []
		@groups.each { |group|
			text << "#[#{group[:name]}]"
			group[:items].each { |item|
				text << item.to_s 
			}
		}
		write_file_host get_host_path , text.join( keycode_newline )
	end
	
	def load_from_file(path)
    unless File.file? path
      puts path + " 不是文件"
      return
    end
    
    name = File.basename(path)
    
    file = readline_file( path )
        
    current_group = nil
    
    group = get_by_group(name)

    file.each do |line|
      line = line.strip.gsub(/#+/,'#')
      if @@IP_REGEX =~ line #item
        if current_group.nil?
          current_group = group
          @groups << group
        end
        item = HostItem.new line , current_group
        @items << item
      elsif @@GRP_REGEX =~ line #group
        nm = @@GRP_REGEX.match( line )[1] 
        current_group = { :name => nm , :items => [] }
        @groups << current_group 
      end
    end
	end
	
	def save_group_to(group_name, path)
	  text = []
	  group_name = group_name || "__safe__"
		g = get_by_group(group_name)
		
		g[:items].each { |item|
			text << item.to_s 
		}
		write_file_host path , text.join( keycode_newline )
	end
	
	def search( pattern , &block )
		result = []
		@items.each do |line|
			if line.is? pattern.to_s
				yield line if block_given?
				result << line
			end
		end
		result
	end 
	
	def keycode_newline
%q{
}
	end
	
	def os_family
		case RUBY_PLATFORM
			when /ix/i, /ux/i, /gnu/i,
				 /sysv/i, /solaris/i,
				 /sunos/i, /bsd/i, /darwin/i
			  "unix"
			when /win/i, /ming/i
			  "windows"
			else
			  "other"
		end
	end

	def get_host_path
		case os_family
			when 'windows'
				File.join( `echo %WINDIR%`.strip , 'system32' , 'drivers' , 'etc' , 'hosts' )
			when 'unix'
				'/etc/hosts'
			else 'other'
				'/etc/hosts'
		end
	end 
	
	def readline_file( file )
		data = []
		f = File.open( file , "r") 
		f.each_line do |line|
			data << line.strip.gsub(/#+/,'#')
		end
		return data
	end 

	def write_file_host( file , text , &block )
		puts "写入文件 -> #{file}"
		File.open( file , 'w' ) do |file|
			file.write(text + keycode_newline)
			yield if block_given?
		end 
	end
	 
	
end
